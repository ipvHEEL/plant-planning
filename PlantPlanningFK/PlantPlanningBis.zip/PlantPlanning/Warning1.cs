﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PlantPlanning
{
    public partial class Warning1 : Form
    {
        FormMain fm;

        public Warning1(FormMain FM)
        {
            InitializeComponent();
            fm = FM;
            textBox1.Clear();

            textBox1.Text = fm.ErrorMainStr;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Warning1_FormClosed(object sender, FormClosedEventArgs e)
        {
            fm.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(textBox1.Text);
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
using Excel1 = Microsoft.Office.Interop.Excel;
using PlantPlanning.Context;

namespace PlantPlanning
{
    public partial class FormFilterResult : Form
    {
        ConsurmptionForm cf;
        FormMain fm;
        List<Material> CFMList;
        DataTable dt1;
        List<DailyResult> MaterialData;
        BindingSource bs;
        DateTime LimitDate;

        public Int32 AxX;
        public Int32 AxY;

        public List<string> CFMListGold;
        public List<string> CFMListGray;
        public List<Colorres> CFMListMinus;
        public List<string> CFMListRed;
        public List<Colorres> CFMListPlus;
        public List<string> CFMListGreen;
        public List<Colorres> CFMListLine;
        public List<string> CFMListPink;
        public List<Colorres> CFMListLinePlus;
        public List<string> CFMListGoldens;

        public List<UserSelectedCell> USCList;

        public FormFilterResult(ConsurmptionForm CF, FormMain FM, DateTime lDate)
        {
            InitializeComponent();
            fm = FM;
            cf = CF;
            CFMList = new List<Material>();
            this.Text = "Компоненты " + cf.comboBoxFiltering.Text;

            cbMaterialDelay.Checked = cf.cbMaterialDelay.Checked;
            cbUseMaterialPlanning.Checked = cf.cbUseMaterialPlanning.Checked;
            cbUsingMaterial.Checked = cf.cbUsingMaterial.Checked;
            cbAddDay.Checked = cf.cbAddDay.Checked;
            cbDontShowAfter.Checked = cf.cbDontShowAfter.Checked;
            cbUsingZero.Checked = cf.cbUsingZero.Checked;
            cbViews.Text = cf.cbViews.Text;
            LimitDate = lDate;

            USCList = new List<UserSelectedCell>();

            LoadData();
            ShowData();
            //  DrawDGV();
        }

        private void DrawDGV()
        {
            Cursor = Cursors.WaitCursor;

            Int32 Offset = cf.WorkMonthList.Count;
            //cells values
            Font f1 = new Font(dataGridViewMain.DefaultCellStyle.Font, FontStyle.Bold);
            //1-2 cells
            for (int j = 0; j < CFMList.Count; j++)
            {
                string PC = dataGridViewMain.Rows[j].Cells[0].Value.ToString();   // CFMList[j].MaterialCode;

                if (cf.URSCodeList.Contains(PC))                 //(dataGridViewMain.Rows[j].Cells["Код материала"].Value.ToString().ToLower() == URSList[i].MaterialCode.ToLower())
                {
                    dataGridViewMain.Rows[j].Cells[0].Style.BackColor = cf.SColor;
                    dataGridViewMain.Rows[j].Cells[1].Style.BackColor = cf.SColor;
                }
                else if (cf.URMCodeList.Contains(PC))
                {
                    dataGridViewMain.Rows[j].Cells[0].Style.BackColor = cf.MColor;
                    dataGridViewMain.Rows[j].Cells[1].Style.BackColor = cf.MColor;
                }
                else if (fm.OPRList.Contains(PC))
                {
                    dataGridViewMain.Rows[j].Cells[0].Style.BackColor = Color.LightCyan;
                    dataGridViewMain.Rows[j].Cells[1].Style.BackColor = Color.LightCyan;
                }
                else if (CFMListGold.Contains(PC))  //cf.
                {
                    if (CFMList[j].MaterialGroup != "ГП") //(CFMBool[j] == false) 
                    {
                        dataGridViewMain.Rows[j].Cells[0].Style.BackColor = Color.LightYellow;
                        dataGridViewMain.Rows[j].Cells[1].Style.BackColor = Color.LightYellow;  //Gold
                    }
                }
                else if (CFMListGray.Contains(PC))  //cf.
                {
                    if (CFMList[j].MaterialGroup != "ГП")
                    {
                        dataGridViewMain.Rows[j].Cells[0].Style.BackColor = Color.LightGray;   //.DarkGray;
                        dataGridViewMain.Rows[j].Cells[1].Style.BackColor = Color.LightGray;
                    }
                }

                if (CFMListRed.Contains(PC)) //-  cf.
                {
                    var CM = CFMListMinus.Where(x => x.ProdCode == PC).ToList();  //cf.
                    if (CM.Count > 0)
                    {
                        foreach (var c in CM[0].ColNo)
                        {
                            try
                            {
                                dataGridViewMain.Rows[j].Cells[c/* + Offset*/].Style.ForeColor = Color.Red;  // Color.DarkRed;
                            }
                            catch (Exception xx)
                            { }
                            try
                            {
                                dataGridViewMain.Rows[j].Cells[c/* + Offset*/].Style.Font = f1;
                            }
                            catch (Exception xx)
                            { }
                        }
                    }
                }

                if (CFMListGreen.Contains(PC))  //+  cf.
                {
                    var CP = CFMListPlus.Where(x => x.ProdCode == PC).ToList(); //cf.
                    if (CP.Count > 0)
                    {
                        foreach (var c in CP[0].ColNo)
                        {
                            try
                            {
                                dataGridViewMain.Rows[j].Cells[c].Style.BackColor = Color.LightGreen;
                            }
                            catch (Exception xx)
                            { }
                        }
                    }
                }

                if (CFMListPink.Contains(PC))   //cf.
                {
                    var CL = CFMListLine.Where(x => x.ProdCode == PC).ToList();  //cf.
                    if (CL.Count > 0)
                    {
                        foreach (var c in CL[0].ColNo)
                        {
                            try
                            {
                                dataGridViewMain.Rows[j].Cells[c].Style.BackColor = Color.LightPink;
                            }
                            catch (Exception xx)
                            { }
                        }
                    }
                }

                if (CFMListGoldens.Contains(PC))   //cf.
                {
                    var CLP = CFMListLinePlus.Where(x => x.ProdCode == PC).ToList();  // cf.
                    if (CLP.Count > 0)
                    {
                        foreach (var c in CLP[0].ColNo)
                        {
                            try
                            {
                                dataGridViewMain.Rows[j].Cells[c].Style.BackColor = Color.LightYellow;
                            }
                            catch (Exception xx)
                            { }
                        }
                    }
                }

                if (cf.TaskList.Contains(PC))
                {
                    dataGridViewMain.Rows[j].Cells[0].Style.BackColor = Color.LightGreen;
                    dataGridViewMain.Rows[j].Cells[1].Style.BackColor = Color.LightGreen;
                }

                //9/10 color
                try
                {
                    var cfm = CFMList.Where(x => x.MaterialCode == PC).First();
                    if (cf.cbMaterialDelay.Checked == false)
                    {
                        dataGridViewMain.Rows[j].Cells[9 + Offset].Style.ForeColor = Color.FromName(cfm.Color1);
                        dataGridViewMain.Rows[j].Cells[10 + Offset].Style.ForeColor = Color.FromName(cfm.Color2);
                    }
                    else
                    {
                        dataGridViewMain.Rows[j].Cells[9 + Offset].Style.ForeColor = Color.FromName(cfm.Color1UD);
                        dataGridViewMain.Rows[j].Cells[10 + Offset].Style.ForeColor = Color.FromName(cfm.Color2UD);
                    }
                }
                catch (Exception xxx)
                { }

                for (int i = 8; i <= 13; i++)
                {
                    dataGridViewMain.Columns[i + Offset].HeaderCell.Style.Font = new Font(dataGridViewMain.ColumnHeadersDefaultCellStyle.Font.FontFamily, 9f, FontStyle.Bold);
                }
            }
            Cursor = Cursors.Default;
        }

        private void LoadData()
        {
            button1_a.BackColor = Color.LightGray; //    Color.DarkGray; #FFFF00 
            button1_b.BackColor = Color.LightPink;    // Color.LightPink;
            button1_c.BackColor = Color.LightYellow;      //Color.Gold;
            button1_d.BackColor = Color.LightCyan;     // Color.SteelBlue;
            button1_e.BackColor = Color.LightGreen;    //Color.Lime;
            button1_f.BackColor = Color.RosyBrown;

            List<string> MatCodeList = cf.FilteredMaterialDataOut.Select(x => x.ProductCode).ToList();
            MaterialData = new List<DailyResult>();

            CFMList = cf.CFMList.Where(x => MatCodeList.Contains(x.MaterialCode)).ToList();
        }

        private void ShowData()
        {
            Cursor = Cursors.WaitCursor;

            dataGridViewMain.DataSource = null;
            dataGridViewMain.Rows.Clear();
            dataGridViewMain.Columns.Clear();
            bs = new BindingSource();
            dt1 = new DataTable();

            string[] NewString;
            char RowSplitter = '|';
            string sVal = "";
            DateTime CurrDate;
            bool fl;
            Int32 J;
            double Value = 0;
            Int32 Cols;
            List<DateTime> DTList1 = new List<DateTime>();
            DTList1 = cf.DTList;
            if (cbDontShowAfter.Checked == true)  //cf.
            {
                var XLD = fm.ExcelDataList[cf.comboBoxFiltering.SelectedIndex];
                //  DateTime LimitDate = XLD.DateWork;
                DTList1 = (from d in DTList1
                           where d <= LimitDate
                           select d).ToList();
            }

            CFMListGold = new List<string>();
            CFMListGray = new List<string>();
            CFMListLine = new List<Colorres>(); //[
            CFMListPink = new List<string>();//[
            CFMListPlus = new List<Colorres>(); //+
            CFMListGreen = new List<string>();//+
            CFMListMinus = new List<Colorres>();//-
            CFMListRed = new List<string>(); //-
            CFMListLinePlus = new List<Colorres>();  //[+
            CFMListGoldens = new List<string>();  //[+
            USCList = new List<UserSelectedCell>();

            dt1.Columns.Clear();
            dt1.Rows.Clear();

            dt1.Columns.Add("Код материала");  //0
            dt1.Columns.Add("Наименование");  //1
            dt1.Columns.Add("Класс материала"); //2
            dt1.Columns.Add("Кратность поставки");  //3
            dt1.Columns.Add("Мин срок пост. дней");//4
            dt1.Columns.Add("Страховой запас");//5
            dt1.Columns.Add("Исполнитель");//6
            dt1.Columns.Add("Поставщик");//7
            //Month need insert
            foreach (var ddd in cf.WorkMonthList)
            {
                dt1.Columns.Add("Потребность на " + ddd.ToString("MM.yyyy"));
            }
            dt1.Columns.Add("Уже потреблено");//8
            dt1.Columns.Add("Остатки склады");//9
            dt1.Columns.Add("Остатки пр-во");//10
            dt1.Columns.Add("Внешние остатки (Собств по НАВ)");//11
            dt1.Columns.Add("Заблокировано (Внешние МЕС)");//12
            dt1.Columns.Add("Старые заявки НАВ");//13

            CurrDate = DateTime.Today.Date;

            if (cbViews.Text == "Остаток")
            {
                foreach (DateTime dt in DTList1)
                {
                    dt1.Columns.Add("Остаток на " + dt.ToString("dd.MM.yyyy"));
                }
            }
            else if (cbViews.Text == "Потребление")
            {
                foreach (DateTime dt in DTList1)
                {
                    dt1.Columns.Add("Потребление на " + dt.ToString("dd.MM.yyyy"));
                }
            }
            else if (cbViews.Text == "Дефицит")
            {
                foreach (DateTime dt in DTList1)
                {
                    dt1.Columns.Add("Дефицит на " + dt.ToString("dd.MM.yyyy"));
                }
            }
            dt1.Columns.Add("Zerrrro");

            MaterialData = CFMList.Select(x => new DailyResult
            {
                ProductCode = x.MaterialCode,
                LineName = x.MaterialName,
                Quantity = 1,
                MaterialType = x.MaterialGroup.Trim()
            }).ToList();
            MaterialData = MaterialData.Distinct().ToList();

            for (int i = 0; i < CFMList.Count; i++)
            {
                sVal = CFMList[i].MaterialCode + RowSplitter + CFMList[i].MaterialName + RowSplitter +
                         CFMList[i].MaterialGroup + RowSplitter + CFMList[i].MaterialMultiplyString + RowSplitter +
                         CFMList[i].WaitingDaysString + RowSplitter + CFMList[i].StorageQuantityString + RowSplitter +
                         CFMList[i].Responsible + RowSplitter + CFMList[i].Sender + RowSplitter;

                for (int j = 0; j < cf.WorkMonthList.Count; j++)
                {
                    if (Math.Abs(CFMList[i].OutList[j].Quantity) <= 1)
                    {
                        sVal = sVal + CFMList[i].OutList[j].Quantity.ToString("N1") + RowSplitter;
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].OutList[j].Quantity.ToString("N0") + RowSplitter;
                    }
                }

                if (Math.Abs(CFMList[i].CurrentConsumption) <= 1)
                {
                    sVal = sVal + CFMList[i].CurrentConsumption.ToString("N1") + RowSplitter;
                }
                else
                {
                    sVal = sVal + CFMList[i].CurrentConsumption.ToString("N0") + RowSplitter;
                }

                if (cbMaterialDelay.Checked == false)
                {
                    if (Math.Abs(CFMList[i].RawStorage) <= 1)
                    {
                        sVal = sVal + CFMList[i].RawStorage.ToString("N1") + RowSplitter;
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].RawStorage.ToString("N0") + RowSplitter;
                    }

                    if (Math.Abs(CFMList[i].RawEnterprise) <= 1)
                    {
                        sVal = sVal + CFMList[i].RawEnterprise.ToString("N1") + RowSplitter;
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].RawEnterprise.ToString("N0") + RowSplitter;
                    }

                    if (Math.Abs(CFMList[i].RawNav1) <= 1)
                    {
                        sVal = sVal + CFMList[i].RawNav1.ToString("N1") + " (";
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].RawNav1.ToString("N0") + " (";
                    }

                    if (Math.Abs(CFMList[i].RawNav2) <= 1)
                    {
                        sVal = sVal + CFMList[i].RawNav2.ToString("N1") + ") " + RowSplitter;
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].RawNav2.ToString("N0") + ") " + RowSplitter;
                    }

                    if (Math.Abs(CFMList[i].RawMesOut2) <= 1)
                    {
                        sVal = sVal + CFMList[i].RawMesOut2.ToString("N1") + " (";
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].RawMesOut2.ToString("N0") + " (";
                    }

                    if (Math.Abs(CFMList[i].RawMesOut1) <= 1)
                    {
                        sVal = sVal + CFMList[i].RawMesOut1.ToString("N0") + ") " + RowSplitter;
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].RawMesOut1.ToString("N0") + ") " + RowSplitter;
                    }

                    if (Math.Abs(CFMList[i].OldTaskNav) <= 1)
                    {
                        sVal = sVal + CFMList[i].OldTaskNav.ToString("N1") + RowSplitter;   //0-12
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].OldTaskNav.ToString("N0") + RowSplitter;   //0-12
                    }
                }
                else
                {
                    if (Math.Abs(CFMList[i].RawStorageUD) <= 1)
                    {
                        sVal = sVal + CFMList[i].RawStorageUD.ToString("N1") + RowSplitter;
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].RawStorageUD.ToString("N0") + RowSplitter;
                    }

                    if (Math.Abs(CFMList[i].RawEnterpriseUD) <= 1)
                    {
                        sVal = sVal + CFMList[i].RawEnterpriseUD.ToString("N1") + RowSplitter;
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].RawEnterpriseUD.ToString("N0") + RowSplitter;
                    }

                    if (Math.Abs(CFMList[i].RawNav1UD) <= 1)
                    {
                        sVal = sVal + CFMList[i].RawNav1UD.ToString("N1") + " (";
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].RawNav1UD.ToString("N0") + " (";
                    }

                    if (Math.Abs(CFMList[i].RawNav2UD) <= 1)
                    {
                        sVal = sVal + CFMList[i].RawNav2UD.ToString("N1") + ") " + RowSplitter;
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].RawNav2UD.ToString("N0") + ") " + RowSplitter;
                    }

                    if (Math.Abs(CFMList[i].RawMesOut2UD) <= 1)
                    {
                        sVal = sVal + CFMList[i].RawMesOut2UD.ToString("N1") + " (";
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].RawMesOut2UD.ToString("N0") + " (";
                    }

                    if (Math.Abs(CFMList[i].RawMesOut1UD) <= 1)
                    {
                        sVal = sVal + CFMList[i].RawMesOut1UD.ToString("N0") + ") " + RowSplitter;
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].RawMesOut1UD.ToString("N0") + ") " + RowSplitter;
                    }

                    if (Math.Abs(CFMList[i].OldTaskNavUD) <= 1)
                    {
                        sVal = sVal + CFMList[i].OldTaskNavUD.ToString("N1") + RowSplitter;   //0-12
                    }
                    else
                    {
                        sVal = sVal + CFMList[i].OldTaskNavUD.ToString("N0") + RowSplitter;   //0-12
                    }
                    /*  sVal = sVal + CFMList[i].RawStorageUD.ToString("N0") + RowSplitter + CFMList[i].RawEnterpriseUD.ToString("N0") + RowSplitter
                           + CFMList[i].RawNav1UD.ToString("N0") + " (" + CFMList[i].RawNav2UD.ToString("N0") + ") " + RowSplitter
                           + CFMList[i].RawMesOut2UD.ToString("N0") + " (" + CFMList[i].RawMesOut1UD.ToString("N0") + ") " + RowSplitter
                           + CFMList[i].OldTaskNavUD.ToString("N0") + RowSplitter;   //0-12*/
                }

                if ((CFMList[i].WaitingDaysString == "") || (CFMList[i].MaterialMultiplyString == ""))
                {
                    CFMListGray.Add(CFMList[i].MaterialCode);
                }

                if (cbViews.Text == "Остаток")  //cf.
                {
                    Value = CFMList[i].CurrentConsumption;

                    if (cbMaterialDelay.Checked == false)
                    {
                        foreach (var sl in CFMList[i].RawStorageList)
                        {
                            Value = Value + sl.Quantity;
                        }

                        foreach (var el in CFMList[i].RawEnterpriseList)
                        {
                            Value = Value + el.Quantity;
                        }
                    }
                    else
                    {
                        foreach (var sl in CFMList[i].RawStorageList.Where(x => x.BBFDate >= DateTime.Today.Date).ToList())
                        {
                            Value = Value + sl.Quantity;
                        }

                        foreach (var el in CFMList[i].RawEnterpriseList.Where(x => x.BBFDate >= DateTime.Today.Date).ToList())
                        {
                            Value = Value + el.Quantity;
                        }
                    }

                    Cols = 14 + cf.WorkMonthList.Count;
                    foreach (DateTime dt in DTList1)
                    {
                        //income
                        double T2 = 0;
                        double T1 = 0;

                        var FDTList = DTList1.Where(x => (x.Month == dt.Month) && (x.Year == dt.Year)).ToList();

                        if (cbUseMaterialPlanning.Checked == true)
                        {
                            List<Raws> tData2 = new List<Raws>();

                            if (cbAddDay.Checked == false)
                            {
                                tData2 = CFMList[i].TaskNavList2.Where(x => x.BBFDate == dt).ToList();
                            }
                            else
                            {
                                tData2 = CFMList[i].TaskNavList2.Where(x => x.AddDate == dt).ToList();
                            }

                            if ((dt.Day == 1) && (FDTList.Count == 1) && (tData2.Count == 0))
                            {
                                tData2 = CFMList[i].TaskNavList2.Where(x => x.AlterDate == dt).ToList();
                            }

                            foreach (var td2 in tData2)
                            {
                                T2 = T2 + td2.Quantity;
                            }

                            List<tPlannedMeatContainers> Cdata = new List<tPlannedMeatContainers>();

                            if (cbAddDay.Checked == false)
                            {
                                Cdata = fm.ContList.Where(x => (x.MaterialCode == CFMList[i].MaterialCode) && (x.ExpDT.Date == dt.Date)).ToList();
                            }
                            else
                            {
                                Cdata = fm.ContList.Where(x => (x.MaterialCode == CFMList[i].MaterialCode) && (x.ExpDT.Date.AddDays(1) == dt.Date)).ToList();
                            }

                            if ((dt.Day == 1) && (FDTList.Count == 1) && (Cdata.Count == 0))
                            {
                                Cdata = fm.ContList.Where(x => (x.MaterialCode == CFMList[i].MaterialCode) && (((DateTime)x.AlterDate).Date == dt.Date)).ToList();
                            }

                            foreach (var cd in Cdata)
                            {
                                T2 = T2 + cd.Quantity;
                            }
                            Value = Value + T2;

                            //ask in progress
                            List<Raws> tData1 = new List<Raws>();

                            if (cbAddDay.Checked == false)
                            {
                                tData1 = CFMList[i].TaskNavList1.Where(x => x.BBFDate == dt).ToList();
                            }
                            else
                            {
                                tData1 = CFMList[i].TaskNavList1.Where(x => x.AddDate == dt).ToList();
                            }

                            if ((dt.Day == 1) && (FDTList.Count == 1) && (tData1.Count == 0))
                            {
                                tData1 = CFMList[i].TaskNavList1.Where(x => x.AlterDate == dt).ToList();
                            }

                            foreach (var td1 in tData1)
                            {
                                T1 = T1 + td1.Quantity;
                            }
                            Value = Value + T1;
                        }

                        //credit
                        if (cbUsingMaterial.Checked == true)
                        {
                            var dll = cf.XLDataList.Where(x => (x.ProdCode == CFMList[i].MaterialCode) && (x.DateWork.Date == dt)).ToList();
                            foreach (var dl in dll)
                            {
                                Value = Value - dl.Quantity;
                            }
                        }

                        //future planning Asks
                        double Q = 0;
                        var adata = cf.AppList;    // fm.tdb.tApplication.ToList();
                        //  if (adata.Count > 0)
                        {
                            adata = adata.Where(x => x.MaterialCode == CFMList[i].MaterialCode).ToList();
                            //    if (adata.Count > 0)
                            {
                                adata = adata.Where(x => x.DateWork.Date == dt.Date).ToList();

                                if ((adata.Count == 0) && (FDTList.Count == 1) && (dt.Day == 1))
                                {
                                    adata = cf.AppList;
                                    adata = adata.Where(x => x.MaterialCode == CFMList[i].MaterialCode).ToList();
                                    adata = adata.Where(x => (DateTime)x.AlterDate == dt.Date).ToList();
                                }

                                foreach (var ad in adata)
                                {
                                    Q = Q + ad.Quantity;
                                }

                                USCList.Add(new UserSelectedCell
                                {
                                    RowIndex = i,
                                    ColIndex = Cols,
                                    Quantity = Q
                                });
                                //  Value = Value + Q;
                            }
                        }

                        if (Value < 0)
                        {
                            if (dt.Subtract(DateTime.Today.Date).Days < 60)
                            {
                                //  CFMBool[i] = false;
                                if (!CFMListGold.Contains(CFMList[i].MaterialCode))  //-
                                {
                                    CFMListGold.Add(CFMList[i].MaterialCode);
                                    CFMListRed.Add(CFMList[i].MaterialCode);
                                    Colorres Col = new Colorres
                                    {
                                        ProdCode = CFMList[i].MaterialCode,
                                        ColNo = new List<int>()
                                    };
                                    Col.ColNo.Add(Cols);
                                    CFMListMinus.Add(Col);
                                }
                                else
                                {
                                    var Coll = CFMListMinus.Where(x => x.ProdCode == CFMList[i].MaterialCode).ToList();
                                    try
                                    {
                                        Coll[0].ColNo.Add(Cols);
                                    }
                                    catch (Exception xx)
                                    {
                                        Colorres Col = new Colorres
                                        {
                                            ProdCode = CFMList[i].MaterialCode,
                                            ColNo = new List<int>()
                                        };
                                        Col.ColNo.Add(Cols);
                                        CFMListMinus.Add(Col);
                                    }
                                }
                            }
                        }

                        if (Math.Abs(Value) <= 1)
                        {
                            sVal = sVal + Value.ToString("N1") + " ";
                        }
                        else
                        {
                            sVal = sVal + Value.ToString("N0") + " ";
                        }

                        if (T2 != 0)
                        {
                            if (Math.Abs(T2) <= 1)
                            {
                                sVal = sVal + " (" + T2.ToString("N1") + ") ";
                            }
                            else
                            {
                                sVal = sVal + " (" + T2.ToString("N0") + ") ";
                            }
                            if (!CFMListGreen.Contains(CFMList[i].MaterialCode))  //+
                            {
                                CFMListGreen.Add(CFMList[i].MaterialCode);
                                Colorres Col = new Colorres
                                {
                                    ProdCode = CFMList[i].MaterialCode,
                                    ColNo = new List<int>()
                                };
                                Col.ColNo.Add(Cols);
                                CFMListPlus.Add(Col);
                            }
                            else
                            {
                                var Coll = CFMListPlus.Where(x => x.ProdCode == CFMList[i].MaterialCode).ToList();
                                try
                                {
                                    Coll[0].ColNo.Add(Cols); ;
                                }
                                catch (Exception xx)
                                {
                                    Colorres Col = new Colorres
                                    {
                                        ProdCode = CFMList[i].MaterialCode,
                                        ColNo = new List<int>()
                                    };
                                    Col.ColNo.Add(Cols);
                                    CFMListPlus.Add(Col);
                                }
                            }
                        }

                        if (T1 != 0)
                        {
                            if (Math.Abs(T1) <= 1)
                            {
                                sVal = sVal + " [" + T1.ToString("N1") + "] ";
                            }
                            else
                            {
                                sVal = sVal + " [" + T1.ToString("N0") + "] ";
                            }

                            if (!CFMListPink.Contains(CFMList[i].MaterialCode))  //[
                            {
                                CFMListPink.Add(CFMList[i].MaterialCode);
                                Colorres Col = new Colorres
                                {
                                    ProdCode = CFMList[i].MaterialCode,
                                    ColNo = new List<int>()
                                };
                                Col.ColNo.Add(Cols);
                                CFMListLine.Add(Col);
                            }
                            else
                            {
                                var Coll = CFMListLine.Where(x => x.ProdCode == CFMList[i].MaterialCode).ToList();
                                try
                                {
                                    Coll[0].ColNo.Add(Cols);
                                }
                                catch (Exception xx)
                                {
                                    Colorres Col = new Colorres
                                    {
                                        ProdCode = CFMList[i].MaterialCode,
                                        ColNo = new List<int>()
                                    };
                                    Col.ColNo.Add(Cols);
                                    CFMListLine.Add(Col);
                                }
                            }

                            if (CFMListGreen.Contains(CFMList[i].MaterialCode))  //[+
                            {
                                if (!CFMListGoldens.Contains(CFMList[i].MaterialCode))
                                {
                                    CFMListGoldens.Add(CFMList[i].MaterialCode);
                                    Colorres Col = new Colorres
                                    {
                                        ProdCode = CFMList[i].MaterialCode,
                                        ColNo = new List<int>()
                                    };
                                    Col.ColNo.Add(Cols);
                                    CFMListLinePlus.Add(Col);
                                }
                                else
                                {
                                    var Coll = CFMListLinePlus.Where(x => x.ProdCode == CFMList[i].MaterialCode).ToList();
                                    try
                                    {
                                        Coll[0].ColNo.Add(Cols);
                                    }
                                    catch (Exception xx)
                                    {
                                        Colorres Col = new Colorres
                                        {
                                            ProdCode = CFMList[i].MaterialCode,
                                            ColNo = new List<int>()
                                        };
                                        Col.ColNo.Add(Cols);
                                        CFMListLinePlus.Add(Col);
                                    }
                                }
                            }
                        }

                        if (Q != 0)
                        {
                            if (Math.Abs(Q) <= 1)
                            {
                                sVal = sVal + " {" + Q.ToString("N1") + "} ";
                            }
                            else
                            {
                                sVal = sVal + " {" + Q.ToString("N0") + "} ";
                            }
                        }

                        sVal = sVal + "" + RowSplitter;
                        Cols = Cols + 1;
                    }
                }  //остаток
                else if (cbViews.Text == "Потребление")
                {
                    var xlData = cf.XLDataList.Where(x => x.ProdCode == CFMList[i].MaterialCode).ToList();

                    foreach (DateTime dt in DTList1)
                    {
                        var xlD = xlData.Where(x => x.DateWork.Date == dt).ToList();

                        if (xlD.Count > 0)
                        {
                            if (Math.Abs(xlD[0].Quantity) <= 1)
                            {
                                sVal = sVal + xlD[0].Quantity.ToString("N1") + RowSplitter;
                            }
                            else
                            {
                                sVal = sVal + xlD[0].Quantity.ToString("N0") + RowSplitter;
                            }
                        }
                        else
                        {
                            sVal = sVal + "" + RowSplitter;
                        }
                    }
                }
                else  //Дефицит
                {
                    Value = 0;

                    if (cbMaterialDelay.Checked == false)
                    {
                        foreach (var sl in CFMList[i].RawStorageList)
                        {
                            Value = Value + sl.Quantity;
                        }

                        foreach (var el in CFMList[i].RawEnterpriseList)
                        {
                            Value = Value + el.Quantity;
                        }
                    }
                    else
                    {
                        foreach (var sl in CFMList[i].RawStorageList.Where(x => x.BBFDate >= DateTime.Today.Date).ToList())
                        {
                            Value = Value + sl.Quantity;
                        }

                        foreach (var el in CFMList[i].RawEnterpriseList.Where(x => x.BBFDate >= DateTime.Today.Date).ToList())
                        {
                            Value = Value + el.Quantity;
                        }
                    }

                    Cols = 14 + cf.WorkMonthList.Count;
                    foreach (DateTime dt in DTList1)
                    {
                        var FDTList = DTList1.Where(x => (x.Month == dt.Month) && (x.Year == dt.Year)).ToList();
                        //income
                        List<Raws> tData2 = new List<Raws>();
                        if (cbAddDay.Checked == false)
                        {
                            tData2 = CFMList[i].TaskNavList2.Where(x => x.BBFDate == dt).ToList();
                        }
                        else
                        {
                            tData2 = CFMList[i].TaskNavList2.Where(x => x.AddDate == dt).ToList();
                        }

                        double T2 = 0;
                        if ((dt.Day == 1) && (FDTList.Count == 1) && (tData2.Count == 0))
                        {
                            tData2 = CFMList[i].TaskNavList2.Where(x => x.AlterDate == dt).ToList();
                        }

                        foreach (var td2 in tData2)
                        {
                            T2 = T2 + td2.Quantity;
                        }

                        List<tPlannedMeatContainers> Cdata = new List<tPlannedMeatContainers>();

                        if (cbAddDay.Checked == false)
                        {
                            Cdata = fm.ContList.Where(x => (x.MaterialCode == CFMList[i].MaterialCode) && (x.ExpDT.Date == dt.Date)).ToList();
                        }
                        else
                        {
                            Cdata = fm.ContList.Where(x => (x.MaterialCode == CFMList[i].MaterialCode) && (x.ExpDT.Date.AddDays(1) == dt.Date)).ToList();
                        }

                        if ((dt.Day == 1) && (FDTList.Count == 1) && (Cdata.Count == 0))
                        {
                            Cdata = fm.ContList.Where(x => (x.MaterialCode == CFMList[i].MaterialCode) && (((DateTime)x.AlterDate).Date == dt.Date)).ToList();
                        }

                        foreach (var cd in Cdata)
                        {
                            T2 = T2 + cd.Quantity;
                        }
                        Value = Value + T2;

                        //ask in progress
                        List<Raws> tData1 = new List<Raws>();

                        if (cbAddDay.Checked == false)
                        {
                            tData1 = CFMList[i].TaskNavList1.Where(x => x.BBFDate == dt).ToList();
                        }
                        else
                        {
                            tData1 = CFMList[i].TaskNavList1.Where(x => x.AddDate == dt).ToList();
                        }
                        double T1 = 0;

                        if ((dt.Day == 1) && (FDTList.Count == 1) && (tData1.Count == 0))
                        {
                            tData1 = CFMList[i].TaskNavList1.Where(x => x.AlterDate == dt).ToList();
                        }

                        foreach (var td1 in tData1)
                        {
                            T1 = T1 + td1.Quantity;
                        }
                        Value = Value + T1;

                        //credit
                        var dll = cf.XLDataList.Where(x => (x.ProdCode == CFMList[i].MaterialCode) && (x.DateWork.Date == dt)).ToList();
                        foreach (var dl in dll)
                        {
                            Value = Value - dl.Quantity;
                        }

                        //future planning Asks
                        double Q = 0;
                        var adata = cf.AppList;    // fm.tdb.tApplication.ToList();
                        //  if (adata.Count > 0)
                        {
                            adata = adata.Where(x => x.MaterialCode == CFMList[i].MaterialCode).ToList();
                            //    if (adata.Count > 0)
                            {
                                adata = adata.Where(x => x.DateWork.Date == dt.Date).ToList();

                                if ((adata.Count == 0) && (FDTList.Count == 1) && (dt.Day == 1))
                                {
                                    adata = cf.AppList;
                                    adata = adata.Where(x => x.MaterialCode == CFMList[i].MaterialCode).ToList();
                                    adata = adata.Where(x => (DateTime)x.AlterDate == dt.Date).ToList();
                                }

                                foreach (var ad in adata)
                                {
                                    Q = Q + ad.Quantity;
                                }

                                USCList.Add(new UserSelectedCell
                                {
                                    RowIndex = i,
                                    ColIndex = Cols,
                                    Quantity = Q
                                });
                                //  Value = Value + Q;
                            }
                        }

                        if (Value < 0)
                        {
                            if (dt.Subtract(DateTime.Today.Date).Days < 60)
                            {
                                //  CFMBool[i] = false;
                                if (!CFMListGold.Contains(CFMList[i].MaterialCode))  //-
                                {
                                    CFMListGold.Add(CFMList[i].MaterialCode);
                                    CFMListRed.Add(CFMList[i].MaterialCode);
                                    Colorres Col = new Colorres
                                    {
                                        ProdCode = CFMList[i].MaterialCode,
                                        ColNo = new List<int>()
                                    };
                                    Col.ColNo.Add(Cols);
                                    CFMListMinus.Add(Col);
                                }
                                else
                                {
                                    var Coll = CFMListMinus.Where(x => x.ProdCode == CFMList[i].MaterialCode).ToList();
                                    try
                                    {
                                        Coll[0].ColNo.Add(Cols);
                                    }
                                    catch (Exception xx)
                                    {
                                        Colorres Col = new Colorres
                                        {
                                            ProdCode = CFMList[i].MaterialCode,
                                            ColNo = new List<int>()
                                        };
                                        Col.ColNo.Add(Cols);
                                        CFMListMinus.Add(Col);
                                    }
                                }
                            }

                            if (Math.Abs(Value) <= 1)
                            {
                                sVal = sVal + Value.ToString("N1") + " ";
                            }
                            else
                            {
                                sVal = sVal + Value.ToString("N0") + " ";
                            }
                        }

                        sVal = sVal + "" + RowSplitter;
                        Cols = Cols + 1;
                    }
                }

                NewString = sVal.Split(RowSplitter);
                dt1.Rows.Add(NewString);
            }

            bs = new BindingSource();
            bs.DataSource = dt1;
            dataGridViewMain.DataSource = bs;

            dataGridViewMain.Columns[0].Width = 80;
            dataGridViewMain.Columns[1].Width = 300;
            dataGridViewMain.Columns[2].Width = 120;
            dataGridViewMain.Columns[6].Width = 100;
            dataGridViewMain.Columns[7].Width = 100;
            dataGridViewMain.Columns[dataGridViewMain.ColumnCount - 1].Visible = false;

            //   DGV_UpdateColumnZero();
            //   DGV_Get_CellColor();

            for (int i = 0; i < 2; i++)
            {
                dataGridViewMain.Columns[i].Frozen = true;
            }

            dataGridViewMain.ReadOnly = true;
            dataGridViewMain.AllowUserToAddRows = false;
            dataGridViewMain.Update();
            //cellcolor

            /* foreach (DataGridViewColumn c in dataGridViewMain.Columns)
             {
                 c.SortMode = DataGridViewColumnSortMode.NotSortable;
             }*/

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            Cursor = Cursors.Default;
        }

        private void ClearDGV()
        {
            dataGridViewMain.ClearSelection();
            dataGridViewMain.CurrentCell = null;

            dgvFactis.Rows.Clear();
            dgvPlanned.Rows.Clear();
            dgvRecipes.Rows.Clear();
            dgvStorages.Rows.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormFilterResult_FormClosed(object sender, FormClosedEventArgs e)
        {
            cf.FilteredMaterialDataOut.Clear();

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();

            cf.Enabled = true;
        }

        private void FormFilterResult_Shown(object sender, EventArgs e)
        {
            DrawDGV();
        }

        private void dataGridViewMain_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Cursor = Cursors.WaitCursor;

            Int32 RowInd = e.RowIndex;
            Int32 ColIndex = e.ColumnIndex;

            Rectangle rect = dataGridViewMain.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true);
            AxX = rect.X +/* fm.Left +*/ this.Left;
            AxY = rect.Y +/* fm.Top + this.panel1.Height + */this.Top + 80;

            if ((RowInd != -1) /*&& (ColIndex != -1)*/)
            {
                string ProductCode = dataGridViewMain.Rows[RowInd].Cells[0].Value.ToString().Trim();
                DateTime CurrDate = DateTime.Today.Date;
                DateTime DateStart = CurrDate.AddHours(8);
                DateTime DateEnd = DateStart.AddDays(1);
                DateTime PlanDate;
                string State = "";

                List<StockBalancesResult> sbrMesList = new List<StockBalancesResult>();
                List<StockBalancesResult> sbrNavList = new List<StockBalancesResult>();
                List<StockBalancesResult> sbrItogList = new List<StockBalancesResult>();
                List<StockBalancesPlant> sbpList = new List<StockBalancesPlant>();
                List<NavPurchaseTable> sListA = new List<NavPurchaseTable>();
                List<NavPurchaseTable> sListB = new List<NavPurchaseTable>();

                string[] dataString;
                bool fl = false;
                double Quantity = 0;
                double Total = 0;
                string LName = "";
                string CurrStr;
                DateTime dt;
                List<DateTime> DDList = new List<DateTime>();

                if (ColIndex > 0)
                {
                    if ((dataGridViewMain.Columns[ColIndex].HeaderText.Contains("Остаток на")) || (dataGridViewMain.Columns[ColIndex].HeaderText.Contains("Потребление на")) || ((dataGridViewMain.Columns[ColIndex].HeaderText.Contains("Дефицит на"))))
                    {
                        LName = dataGridViewMain.Columns[ColIndex].HeaderText;
                        LName = LName.Substring(LName.Length - 11, 11).Trim();
                        fl = true;

                        CurrDate = fm.ConvertDataToDate(LName);
                        DateStart = CurrDate.AddHours(8);
                        DateEnd = DateStart.AddDays(1);
                        Quantity = fm.ConvertStringToDouble(dataGridViewMain.Rows[RowInd].Cells[ColIndex].Value.ToString().Trim());
                    }
                    else
                    {
                        CurrDate = DateTime.Today.Date;
                    }
                }
                else
                {
                    CurrDate = DateTime.Today.Date;
                }

                dgvPlanned.Rows.Clear();
                dgvRecipes.Rows.Clear();
                dgvFactis.Rows.Clear();
                dgvStorages.Rows.Clear();

                //storages
                {
                    var LocSBList = cf.SBList.Where(x => x.MaterialCode == ProductCode).ToList();
                    //  LocSBList = LocSBList.Where(x => x.DayPeriod == "день").ToList();
                    var LocSBMList = cf.SBMList.Where(x => x.MaterialCode == ProductCode).ToList();
                    //    LocSBMList = LocSBMList.Where(x => x.DayPeriod == "день").ToList();
                    var LocSBPList = cf.SBPList.Where(x => x.MaterialCode == ProductCode).ToList();
                    //    LocSBPList = LocSBPList.Where(x => x.DayPeriod == "день").ToList();
                    var sbmdList = LocSBMList.Where(d => (d.WorkDate.Hour >= 6) && (d.WorkDate.Hour <= 10)).ToList();
                    var sbmnList = LocSBMList.Where(d => (d.WorkDate.Hour >= 18) && (d.WorkDate.Hour <= 22)).ToList();

                    var sbrld = sbmdList.GroupBy(x => new { x.Storage, x.MaterialCode, x.MaterialLot }).
                                  Select(g => new StockBalancesResult
                                  {
                                      WorkDate = DateTime.Today.Date,
                                      Storage = g.Key.Storage.Trim(),
                                      MaterialCode = g.Key.MaterialCode.Trim(),
                                      LotName = g.Key.MaterialLot.Trim(),
                                      QuantityMesDay = g.Sum(x => x.Quantity),

                                  }).ToList();

                    var sbrln = sbmnList.GroupBy(x => new { x.Storage, x.MaterialCode, x.MaterialLot }).
                      Select(g => new StockBalancesResult
                      {
                          WorkDate = DateTime.Today.Date,
                          Storage = g.Key.Storage.Trim(),
                          MaterialCode = g.Key.MaterialCode.Trim(),
                          LotName = g.Key.MaterialLot.Trim(),
                          QuantityMesNight = g.Sum(x => x.Quantity)
                      }).ToList();
                    //mes
                    foreach (StockBalancesResult s in sbrld)
                    {
                        var m = new StockBalancesResult
                        {
                            WorkDate = s.WorkDate,
                            Storage = s.Storage,
                            LotName = s.LotName,
                            LotDescription = s.LotDescription,
                            MaterialCode = s.MaterialCode,
                            QuantityMesDay = s.QuantityMesDay
                        };

                        sbrMesList.Add(m);
                    }

                    foreach (var s in sbrln)
                    {
                        var m = new StockBalancesResult
                        {
                            WorkDate = s.WorkDate,
                            Storage = s.Storage,
                            LotName = s.LotName,
                            LotDescription = s.LotDescription,
                            MaterialCode = s.MaterialCode,
                            QuantityMesNight = s.QuantityMesNight
                        };

                        var sss = sbrMesList.Where(x => (x.Storage == m.Storage) && (x.MaterialCode == m.MaterialCode) && (x.LotName == m.LotName)).ToList();

                        if (sss.Count > 0)
                        {
                            foreach (var sl in sss)
                            {
                                sl.QuantityMesNight = m.QuantityMesNight;
                                sl.QuantityMesDelta = sl.QuantityMesDay - sl.QuantityMesNight;
                            }
                        }
                        else
                        {
                            m.QuantityMesDelta = (-1) * m.QuantityMesNight;
                            sbrMesList.Add(m);
                        }
                    }
                    //nav 
                    var sbList = LocSBList.Where(d => (d.WorkDate.Hour >= 18) && (d.WorkDate.Hour <= 22)).ToList();

                    var sbrl = sbList.GroupBy(x => new { x.Storage, x.MaterialCode, x.LotName }).
                                  Select(g => new StockBalancesResult
                                  {
                                      WorkDate = DateTime.Today.Date,
                                      Storage = g.Key.Storage.Trim(),
                                      MaterialCode = g.Key.MaterialCode.Trim(),
                                      LotName = g.Key.LotName.Trim(),
                                      QuantityStorageNight = (double)g.Sum(x => x.Quantity)
                                  }).ToList();

                    foreach (var s in sbrl)
                    {
                        var m = new StockBalancesResult
                        {
                            WorkDate = s.WorkDate,
                            Storage = s.Storage,
                            LotName = s.LotName,
                            LotDescription = s.LotDescription,
                            MaterialCode = s.MaterialCode,
                            QuantityStorageNight = s.QuantityStorageNight
                        };

                        var sss = sbrMesList.Where(x => (x.Storage == m.Storage) && (x.MaterialCode == m.MaterialCode) && (x.LotName == m.LotName)).ToList();

                        if (sss.Count > 0)
                        {
                            foreach (var sl in sss)
                            {
                                sl.QuantityStorageNight = m.QuantityStorageNight;
                                sl.QuantityStorageDay = m.QuantityStorageNight - sl.QuantityMesDelta;
                                sl.Storage = m.Storage;
                            }
                        }
                        else
                        {
                            m.QuantityStorageDay = m.QuantityStorageNight;
                            sbrMesList.Add(m);
                        }
                    }

                    //    if (cbMaterialDelay.Checked == false)
                    {
                        sbrMesList = sbrMesList.Where(x => x.QuantityStorageDay != 0).OrderBy(x => x.Storage).ThenBy(x => x.LotName).ToList();
                    }
                    /*   else
                       {
                           sbrMesList = sbrMesList.Where(x => (x.QuantityStorageDay != 0)&&(x.BBFDate>=DateTime.Today.Date)).OrderBy(x => x.Storage).ThenBy(x => x.LotName).ToList();
                       }*/

                    foreach (var s in sbrMesList)
                    {
                        List<StockBalances> sl = new List<StockBalances>();
                        if (cf.cbMaterialDelay.Checked == false)
                        {
                            sl = cf.SBList.Where(x => (x.Storage == s.Storage) && (x.MaterialCode == s.MaterialCode) && (x.LotName == s.LotName)).ToList();
                        }
                        else
                        {
                            sl = cf.SBList.Where(x => (x.Storage == s.Storage) && (x.MaterialCode == s.MaterialCode) && (x.LotName == s.LotName) && (x.BBFDate >= DateTime.Today.Date)).ToList();
                        }

                        if (sl.Count > 0)
                        {
                            s.ProdDate = sl[sl.Count - 1].ProdDate;
                            s.BBFDate = sl[sl.Count - 1].BBFDate;
                            if ((s.BBFDate - DateTime.Today.Date).Days > 30)
                            {
                                s.Status = "Green";
                            }
                            else if ((s.BBFDate - DateTime.Today.Date).Days > 20)
                            {
                                s.Status = "Magenta";
                            }
                            else if ((s.BBFDate - DateTime.Today.Date).Days > 0)
                            {
                                s.Status = "DarkOrange";
                            }
                            else
                            {
                                s.Status = "Red";
                            }
                        }
                        else
                        {
                            s.Status = "GrayText";
                            s.ProdDate = DateTime.Today.Date.AddDays(-5);
                            s.BBFDate = DateTime.Today.Date.AddDays(-5);
                        }

                    }

                    if (cf.cbMaterialDelay.Checked == true)
                    {
                        sbrMesList = sbrMesList.Where(x => x.BBFDate >= DateTime.Today.Date).ToList();
                    }

                    if (sbrMesList.Count > 0)
                    {
                        dataString = new string[]
                        {
                                "Остатки склады:",
                                "",
                                "",
                                "",
                                "",
                                ""
                        };
                        dgvStorages.Rows.Add(dataString);

                        foreach (var ss in sbrMesList)
                        {
                            dataString = new string[]
                            {
                                    ss.Storage,
                                    ss.LotName,
                                    ss.QuantityStorageDay.ToString("N1"),
                                    ss.ProdDate.ToString("dd.MM.yyyy"),
                                    ss.BBFDate.ToString("dd.MM.yyyy"),
                                    ss.Status
                            };
                            dgvStorages.Rows.Add(dataString);
                        }

                        dataString = new string[]
                         {
                                "",
                                "",
                                "",
                                "",
                                "",
                                ""
                         };
                        dgvStorages.Rows.Add(dataString);
                    }
                    //plant
                    if (cf.cbMaterialDelay.Checked == false)
                    {
                        sbpList = cf.SBPList.Where(x => (x.MaterialCode == ProductCode) && (x.Quantity != 0)).ToList();
                    }
                    else
                    {
                        sbpList = cf.SBPList.Where(x => (x.MaterialCode == ProductCode) && (x.ValidTo >= DateTime.Today.Date) && (x.Quantity != 0)).ToList();
                    }

                    foreach (var s1 in sbpList)
                    {
                        //  DateTime pDzate = s1.ValidFrom;
                        DateTime pBDzate = s1.ValidTo;

                        if ((pBDzate - DateTime.Today.Date).Days > 30)
                        {
                            s1.Status = "Green";
                        }
                        else if ((pBDzate - DateTime.Today.Date).Days > 20)
                        {
                            s1.Status = "Magenta";
                        }
                        else if ((pBDzate - DateTime.Today.Date).Days > 0)
                        {
                            s1.Status = "DarkOrange";
                        }
                        else
                        {
                            s1.Status = "Red";
                        }

                    }

                    if (sbpList.Count > 0)
                    {
                        dataString = new string[]
                            {
                                "Остатки производство:",
                                "",
                                "",
                                "",
                                "",
                                ""
                            };
                        dgvStorages.Rows.Add(dataString);

                        foreach (var ss in sbpList)
                        {
                            dataString = new string[]
                             {
                                    ss.LineName,
                                    ss.MaterialLotName,
                                    ss.Quantity.ToString("N1"),
                                    ss.ValidFrom.ToString("dd.MM.yyyy"),
                                    ss.ValidTo.ToString("dd.MM.yyyy"),
                                    ss.Status
                             };
                            dgvStorages.Rows.Add(dataString);

                        }

                        dataString = new string[]
                         {
                                "",
                                "",
                                "",
                                "",
                                "",
                                ""
                        };
                        dgvStorages.Rows.Add(dataString);
                    }
                    //tasks

                    if (cf.cbMaterialDelay.Checked == false)
                    {
                        sListA = fm.StorageList.Where(x => (x.MaterialCode == ProductCode) && (x.StatusMZP.Trim() == "")).OrderBy(x => x.PlanOperDate).ToList();
                        sListB = fm.StorageList.Where(x => (x.MaterialCode == ProductCode) && (x.StatusMZP.Trim().ToLower() != "")).OrderBy(x => x.PlanOperDate).ToList();
                    }
                    else
                    {
                        sListA = fm.StorageList.Where(x => (x.MaterialCode == ProductCode) && (x.PlanOperDate.Date >= DateTime.Today.Date) && (x.StatusMZP.Trim() == "")).OrderBy(x => x.PlanOperDate).ToList();
                        sListB = fm.StorageList.Where(x => (x.MaterialCode == ProductCode) && (x.PlanOperDate.Date >= DateTime.Today.Date) && (x.StatusMZP.Trim().ToLower() != "")).OrderBy(x => x.PlanOperDate).ToList();
                    }

                    var sListBB = sListB.Where(x => /*(x.PlanOperDate.Date >= DateTime.Today.Date) &&*/ (x.StatusMZP.Trim().ToLower() == "заказано")).ToList();

                    //containers
                    var cList = fm.ContList.Where(x => (x.MaterialCode == ProductCode)).OrderBy(x => x.ExpDT).ToList();
                    cList = cList.Where(x => x.ExpDT >= DateTime.Today.Date).ToList();

                    foreach (var c in cList)
                    {
                        NavPurchaseTable npt = new NavPurchaseTable
                        {
                            PlanOperDate = c.ExpDT,
                            PlanDate = c.ExpDT,
                            PlanQuantity = c.Quantity,
                            FactQuantity = c.Quantity,
                            OrderNymber = c.LotNo,
                            MZP = "",
                            Initiator = "",
                            MaterialCode = c.MaterialCode,
                            StatusMZP = c.LotDescription
                        };
                        sListBB.Add(npt);
                    }

                    if (sListA.Count > 0)
                    {
                        dataString = new string[]
                         {
                                "Запланированные заявки навижн:",
                                "",
                                "",
                                "",
                                "",
                                ""
                        };
                        dgvStorages.Rows.Add(dataString);

                        foreach (var s in sListA)
                        {
                            PlanDate = s.PlanOperDate;
                            if ((PlanDate - DateTime.Today.Date).Days > 30)
                            {
                                State = "Green";
                            }
                            else if ((PlanDate - DateTime.Today.Date).Days > 20)
                            {
                                State = "Magenta";
                            }
                            else if ((PlanDate - DateTime.Today.Date).Days > 0)
                            {
                                State = "DarkOrange";
                            }
                            else
                            {
                                State = "Red";
                            }

                            dataString = new string[]
                             {
                                    s.OrderNymber,
                                    s.PlanOperDate.ToString("dd.MM.yyyy")+" "+s.Initiator+" "+s.StatusMZP,
                                    (s.PlanQuantity - s.FactQuantity).ToString("N1"),   //FactQuantity
                                    PlanDate.ToString("dd.MM.yyyy"),
                                    PlanDate.ToString("dd.MM.yyyy"),
                                    State
                             };
                            dgvStorages.Rows.Add(dataString);
                        }

                        dataString = new string[]
                        {
                                "",
                                "",
                                "",
                                "",
                                "",
                                ""
                        };
                        dgvStorages.Rows.Add(dataString);
                    }

                    if (sListBB.Count > 0)
                    {
                        dataString = new string[]
                         {
                                "Рабочие заявки навижн:",
                                "",
                                "",
                                "",
                                "",
                                ""
                        };
                        dgvStorages.Rows.Add(dataString);

                        foreach (var s in sListBB)
                        {
                            PlanDate = s.PlanOperDate;
                            if ((PlanDate - DateTime.Today.Date).Days > 30)
                            {
                                State = "Green";
                            }
                            else if ((PlanDate - DateTime.Today.Date).Days > 20)
                            {
                                State = "Magenta";
                            }
                            else if ((PlanDate - DateTime.Today.Date).Days > 0)
                            {
                                State = "DarkOrange";
                            }
                            else
                            {
                                State = "Red";
                            }

                            dataString = new string[]
                             {
                                    s.MZP.Trim()==""? s.OrderNymber:  s.OrderNymber+"/"+s.MZP,
                                    s.PlanOperDate.ToString("dd.MM.yyyy")+" "+s.Initiator+" "+s.StatusMZP,
                                    (s.PlanQuantity-s.FactQuantity).ToString("N1"),  //FactQuantity
                                    PlanDate.ToString("dd.MM.yyyy"),
                                    PlanDate.ToString("dd.MM.yyyy"),
                                    State
                             };
                            dgvStorages.Rows.Add(dataString);
                        }

                        dataString = new string[]
                        {
                                "",
                                "",
                                "",
                                "",
                                "",
                                ""
                        };
                        dgvStorages.Rows.Add(dataString);
                    }

                    foreach (DataGridViewRow r in dgvStorages.Rows)
                    {
                        if (r.Cells[3].Value.ToString() != "")
                        {
                            r.Cells[0].ToolTipText = "Произведен: " + r.Cells[3].Value.ToString() + "; Годен до: " + r.Cells[4].Value.ToString();
                            r.Cells[1].ToolTipText = "Произведен: " + r.Cells[3].Value.ToString() + "; Годен до: " + r.Cells[4].Value.ToString();
                            r.Cells[2].ToolTipText = "Произведен: " + r.Cells[3].Value.ToString() + "; Годен до: " + r.Cells[4].Value.ToString();
                        }

                    }
                }//storages, plant and tasks

                //     //reciepts, planned, fact etc
                //   if (fl == true)
                {
                    dataString = new string[] { "", "", "", "Данный компонент используется в:" };
                    dgvPlanned.Rows.Add(dataString);
                    dataString = new string[] { "", "", "", "", "", "Данный компонент используется в:" };
                    dgvFactis.Rows.Add(dataString);

                    List<DateTime> DList = new List<DateTime>();
                    DList = fm.ExcelDataList.Select(x => x.DateWork).ToList();
                    DList = DList.Distinct().OrderBy(x => x.Date).ToList();

                    DateTime StartDate1;
                    DateTime EndDate1;

                    try
                    {
                        StartDate1 = DList.Min();
                        EndDate1 = DList.Max();
                    }
                    catch (Exception xx)
                    {
                        StartDate1 = DateTime.Today.Date;
                        EndDate1 = StartDate1.AddDays(1);
                    }

                    var CurProduct = fm.lRec.Where(x => x.MaterialCode == ProductCode).ToList();  //fm.tdb.fn_select_CurrentProductView(ProductCode).ToList();   //fm.tdb.fn_select_CurrentProductS(ProductCode).ToList();      //fm.tdb.fn_select_CurrentProduct1(dt1, ProductCode).ToList();
                                                                                                  /*foreach (var cp in CurProduct)
                                                                                                  {
                                                                                                      cp.LineNumber = fm.ReplaceLineName(cp.LineNumber);
                                                                                                  }*/

                    if (ColIndex < 8)
                    {
                        DDList = DList;
                    }
                    else
                    {
                        DDList = DList.Where(x => x.Date >= DateTime.Today.Date).OrderBy(x => x.Date).ToList();
                    }

                    foreach (DateTime dt1 in DDList)   //DList
                    {
                        //planned
                        //  if (dt1 >= DateTime.Today.Date)
                        {
                            fl = dataGridViewMain.Rows[RowInd].Cells["Класс материала"].Value.ToString().ToLower() == "тара" ? true : false;
                            var ELDListDate = fm.ExcelDataList.Where(x => (x.DateWork == dt1) && (x.Quantity > 0)).ToList();    // XLDataList.Where(x => (x.DateWork == CurrDate) && (x.Quantity > 0)).ToList();  //CurrDate

                            foreach (var ELD in ELDListDate)
                            {
                                var CP = CurProduct.Where(x => (x.ProductCode == ELD.ProdCode) && (x.LineNumber == ELD.Line) && (x.WorkDate <= dt1)).ToList();  // (x.Prod_No == ELD.ProdCode) && (x.WorkCenter == ELD.Line)
                                                                                                                                                                //   CP = CP.Where(x => x.WorkDate < dt1).OrderByDescending(x => x.WorkDate).ToList();  //Starting_Date

                                fn_select_RecipesView_Result SRR;
                                try
                                {
                                    //  CP = CP.Where(x => x.WorkDate <= dt1).OrderByDescending(x => x.WorkDate).ToList();
                                    SRR = CP.OrderByDescending(x => x.WorkDate).First();      // CP = CP.Where(x => x.WorkDate <= dt1).OrderByDescending(x => x.WorkDate).ToList();  //x.Starting_Date
                                }
                                catch (Exception xx)
                                {
                                    SRR = null;
                                }

                                if (SRR != null)    // (CP.Count > 0)
                                {
                                    //раскрутка рецептуры в обратном направлении! Продукт-Линия-совпадает ли дата?
                                    var PRL = fm.ProdRecipeList.Where(x => x.ProductCode == ELD.ProdCodeStr).ToList();
                                    if (PRL.Count > 0)
                                    {
                                        var LL = PRL[0].RecLineList.Where(x => x.LineNumber == ELD.Line).ToList();
                                        if (LL.Count > 0)
                                        {
                                            var DL = LL[0].RecList.Where(x => x.WorkDateStart <= dt1).OrderByDescending(x => x.WorkDateStart).ToList();  // CurrDate
                                            if (DL.Count > 0)
                                            {
                                                if (DL[0].WorkDateStart == SRR.WorkDate)
                                                {
                                                    if (ELD.RePack == true)
                                                    {
                                                        if (fl == true)
                                                        {
                                                            if ((double)SRR.Quantity > 0)
                                                            {
                                                                dataString = new string[] {
                                                                    dt1.ToString("dd.MM.yyyy"),  //  CurrDate
                                                                    ELD.Line,
                                                                    ELD.ProdCodeStr,
                                                                    ELD.AlterProdName,
                                                                    ELD.Quantity.ToString("N0"),
                                                                    ((double) SRR.Quantity).ToString("N5"),   //CP[0].Quantity
                                                                    (((double) SRR.Quantity) * ELD.Quantity).ToString("N1")
                                                                 };

                                                                dgvPlanned.Rows.Add(dataString);
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        if ((double)SRR.Quantity > 0)
                                                        {
                                                            dataString = new string[] {
                                                                dt1.ToString("dd.MM.yyyy"),
                                                                ELD.Line,
                                                                ELD.ProdCodeStr,
                                                                ELD.AlterProdName,
                                                                ELD.Quantity.ToString("N0"),
                                                                ((double) SRR.Quantity).ToString("N5"),
                                                                (((double) SRR.Quantity) * ELD.Quantity).ToString("N1")
                                                            };

                                                            dgvPlanned.Rows.Add(dataString);
                                                        }

                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            foreach (DataGridViewRow r in dgvPlanned.Rows)
                            {
                                if (r.Cells[0].Value.ToString() != "")
                                {
                                    r.Cells[0].ToolTipText = "Количество: " + r.Cells[4].Value.ToString() + "; Норма на 1 кг: " + r.Cells[5].Value.ToString() + " Итого расход: " + r.Cells[6].Value.ToString();
                                    r.Cells[1].ToolTipText = "Количество: " + r.Cells[4].Value.ToString() + "; Норма на 1 кг: " + r.Cells[5].Value.ToString() + " Итого расход: " + r.Cells[6].Value.ToString();
                                    r.Cells[2].ToolTipText = "Количество: " + r.Cells[4].Value.ToString() + "; Норма на 1 кг: " + r.Cells[5].Value.ToString() + " Итого расход: " + r.Cells[6].Value.ToString();
                                    //   r.Cells[3].ToolTipText = "Количество: " + r.Cells[4].Value.ToString() + "; Норма на 1 кг: " + r.Cells[5].Value.ToString() + " Итого расход: " + r.Cells[6].Value.ToString();
                                }
                            }

                            ELDListDate = null;
                        }  //dt1
                    }  //foreach
                    //fact
                    {
                        fl = dataGridViewMain.Rows[RowInd].Cells["Класс материала"].Value.ToString().ToLower() == "тара" ? true : false;
                        //  var MuaSection = fm.MUAList.Where(x => (x.DateTime >= DateStart) && (x.DateTime < DateEnd)).ToList();    

                        var FactData = fm.tdb.fn_select_ProductionByCode(ProductCode, DateTime.Today.Date.AddYears(-2)).OrderBy(x => x.LotForErp).ToList();                      //fm.edb.fn_select_MaterialUsingByProduct(StartDate1, EndDate1, ProductCode).OrderBy(x => x.DateStart).ToList();

                        List<string> LotForErp = FactData.Select(x => x.LotForErp).Distinct().ToList();
                        List<fn_select_ProductionByCode_Result> FactData1 = new List<fn_select_ProductionByCode_Result>();

                        foreach (string lfe in LotForErp)
                        {
                            var fd = FactData.Where(x => x.LotForErp == lfe).ToList();

                            if (fd.Count > 0)
                            {
                                var fd1 = fd[0];

                                for (int i = 1; i < fd.Count; i++)
                                {
                                    fd1.Quantity = fd1.Quantity + fd[i].Quantity;
                                    fd1.RawQuant = fd1.RawQuant + fd[i].RawQuant;
                                }
                                fd1.EndDate = fd[fd.Count - 1].EndDate;
                            }
                        }

                        foreach (var f in FactData)
                        {
                            // if (f.DateStart >= DateStart)
                            {
                                dataString = new string[]
                                {
                                    ((double)f.RawQuant).ToString("N3"),
                                    ((DateTime)f.StartDate).ToString("dd.MM.yyyy HH;mm"),
                                    ((DateTime)f.EndDate).ToString("dd.MM.yyyy HH:mm"),
                                    f.LotForErp,
                                    f.MaterialCode,
                                    f.SystemName+" "+ f.MaterialName,
                                    ((double)f.Quantity).ToString("N2")
                                };

                                dgvFactis.Rows.Add(dataString);
                            }
                        }

                        foreach (DataGridViewRow r in dgvFactis.Rows)
                        {
                            if (r.Cells[0].Value.ToString() != "")
                            {
                                r.Cells[0].ToolTipText = "Произведено: " + r.Cells[6].Value.ToString() + "; Итого расход: " + r.Cells[0].Value.ToString();
                                r.Cells[1].ToolTipText = "Произведено: " + r.Cells[6].Value.ToString() + "; Итого расход: " + r.Cells[0].Value.ToString();
                                r.Cells[2].ToolTipText = "Произведено: " + r.Cells[6].Value.ToString() + "; Итого расход: " + r.Cells[0].Value.ToString();
                                //  r.Cells[3].ToolTipText = "Произведено: " + r.Cells[6].Value.ToString() + "; Итого расход: " + r.Cells[0].Value.ToString();
                            }
                        }

                        FactData = null;
                    }

                    //recipes
                    var PRListA = fm.ProdRecipeList.Where(x => x.ProductCode == ProductCode).ToList();     //PRList.Where(x => x.ProductCode == ProductCode).ToList();
                    if (PRListA.Count > 0)
                    {
                        dataString = new string[] { "", "Рецепты с разбиением по линиям, действующие с " + CurrDate.ToString("dd.MM.yyyy") + ":" };//+ System.Environment.NewLine + System.Environment.NewLine;
                        dgvRecipes.Rows.Add(dataString);
                    }
                    foreach (var prA in PRListA)
                    {
                        var PRListLines = prA.RecLineList;

                        foreach (var PRL in PRListLines)
                        {
                            var Recipesl = PRL.RecList.Where(x => (x.WorkDateStart <= CurrDate) && (x.WorkDateEnd >= CurrDate)).ToList();
                            if (Recipesl.Count > 0)
                            {
                                dataString = new string[] { "", PRL.LineNumber };
                                dgvRecipes.Rows.Add(dataString);
                            }

                            foreach (var RL in Recipesl)
                            {
                                var RecList = RL.rList;

                                foreach (var rrr in RecList)
                                {
                                    dataString = new string[] { rrr.MaterialCode,
                                                                rrr.MaterialName,
                                                                rrr.MaterialQuantity.ToString("N6"),
                                                                (Quantity * rrr.MaterialQuantity).ToString("N3") };
                                    dgvRecipes.Rows.Add(dataString);
                                }
                            }
                        }
                    }
                }  //fl==true

                //MenuStrip
                contextMenuStripData.Items.Clear();

                if (dataGridViewMain.Rows[e.RowIndex].Cells["Класс материала"].Value.ToString().ToLower() == "гп")
                {
                    ToolStripMenuItem m1;
                    Int32 Offset = cf.WorkMonthList.Count;
                    cf.UserSelectedCode = dataGridViewMain.Rows[e.RowIndex].Cells[0].Value.ToString();
                    if (ColIndex > 13 + Offset)
                    {
                        if ((dataGridViewMain.Columns[ColIndex].HeaderText.Contains("Остаток на")) || (dataGridViewMain.Columns[ColIndex].HeaderText.Contains("Потребление на")) || ((dataGridViewMain.Columns[ColIndex].HeaderText.Contains("Дефицит на"))))
                        {
                            LName = dataGridViewMain.Columns[e.ColumnIndex].HeaderText;
                            LName = LName.Substring(LName.Length - 11, 11).Trim();
                            CurrDate = fm.ConvertDataToDate(LName);
                        }
                        else
                        {
                            CurrDate = DateTime.Today.Date;
                        }


                        var ExData = cf.XLDataList.Where(x => (x.ProdCode == cf.UserSelectedCode) && (x.DateWork == CurrDate)).ToList(); //fm.ExcelList.Where(x => (x.ProductCode == UserSelectedCode) && (x.DateWork == dt)).ToList();

                        foreach (var ed in ExData)
                        {
                            //  foreach (var xd in ed.EDList)
                            {
                                LName = ed.Quantity.ToString("N1") + " => " + ed.Line;
                                if (ed.RePack == true)
                                {
                                    LName = LName + " П/УП";
                                }

                                contextMenuStripData.Items.Add(LName);
                            }
                        }

                        if (ExData.Count > 1)
                        {
                            LName = "__________";
                            contextMenuStripData.Items.Add(LName);
                            LName = "Итого: " + (ExData.Sum(x => x.Quantity)).ToString("N1");
                            contextMenuStripData.Items.Add(LName);
                        }
                    }
                    else if (e.ColumnIndex == (8 + Offset))
                    {
                        var CM = CFMList.Where(x => x.MaterialCode == cf.UserSelectedCode).ToList();

                        if (CM.Count > 0)
                        {
                            foreach (var cl in CM[0].ConsurmptionList)
                            {
                                m1 = new ToolStripMenuItem(cl.Storage + " => " + cl.Quantity.ToString("N1"));
                                contextMenuStripData.Items.Add(m1);
                            }
                        }

                        /* if (CM[0].ConsurmptionList.Count > 1)
                         {
                             LName = "__________";
                             contextMenuStripData.Items.Add(LName);
                             LName = "Итого: " + (CM[0].ConsurmptionList.Sum(x => x.Quantity)).ToString("N1");
                             contextMenuStripData.Items.Add(LName);
                         }*/
                    }
                    else if (e.ColumnIndex == (9 + Offset))
                    {
                        var ListAA = sbrMesList.GroupBy(x => new { x.Storage, x.LotName, x.ProdDate, x.BBFDate, x.Status }).
                                     Select(g => new PurchTable
                                     {
                                         PlanOperDate = g.Key.ProdDate,
                                         BBFDate = g.Key.BBFDate,
                                         OrderNymber = g.Key.Storage,
                                         LostDescr = g.Key.LotName,
                                         PlanQuantity = g.Sum(x => x.QuantityStorageDay),
                                         Status = g.Key.Status,
                                         Count = g.Count()
                                     }).ToList();

                        if (cf.cbMaterialDelay.Checked == true)
                        {
                            ListAA = ListAA.Where(x => x.BBFDate >= DateTime.Today.Date).ToList();
                        }

                        foreach (var sml in ListAA.OrderBy(x => x.PlanOperDate)) //sbrMesList)
                        {
                            m1 = new ToolStripMenuItem(sml.OrderNymber + " [" + sml.LostDescr + "] => " + sml.PlanQuantity.ToString("N1"));
                            m1.ToolTipText = "Выпущен: " + sml.PlanOperDate.ToString("dd.MM.yyyy") + "; Годен до: " + sml.BBFDate.ToString("dd.MM.yyyy"); // +"; К-во: "+sml.Count.ToString();
                            try
                            {
                                m1.ForeColor = Color.FromName(sml.Status);
                            }
                            catch (Exception xx)
                            {
                                m1.ForeColor = Color.Violet;
                            }

                            contextMenuStripData.Items.Add(m1);
                        }

                        /*  if (ListAA.Count > 1)
                          {
                              LName = "__________";
                              contextMenuStripData.Items.Add(LName);
                              LName = "Итого: " + (ListAA.Sum(x => x.PlanQuantity)).ToString("N1");
                              contextMenuStripData.Items.Add(LName);
                          }*/
                    }
                    else if (e.ColumnIndex == (10 + Offset))
                    {
                        var ListBB = sbpList.GroupBy(x => new { x.LineName, x.MaterialLotName, x.ValidFrom, x.ValidTo, x.Status }).
                                    Select(g => new PurchTable
                                    {
                                        OrderNymber = g.Key.LineName,
                                        LostDescr = g.Key.MaterialLotName,
                                        PlanQuantity = g.Sum(x => x.Quantity),
                                        PlanOperDate = g.Key.ValidFrom,
                                        BBFDate = g.Key.ValidTo,
                                        Status = g.Key.Status,
                                        Count = g.Count()
                                    }).ToList();

                        if (cf.cbMaterialDelay.Checked == true)
                        {
                            ListBB = ListBB.Where(x => x.BBFDate >= DateTime.Today.Date).ToList();
                        }

                        foreach (var sl1 in ListBB.OrderBy(x => x.PlanOperDate)) //sbpList)
                        {
                            ToolStripMenuItem m2 = new ToolStripMenuItem(sl1.OrderNymber + " [" + sl1.LostDescr + "] => " + sl1.PlanQuantity.ToString("N1"));
                            //      m2.ToolTipText = "Количество записей: " + sl1.Count.ToString();
                            m2.ToolTipText = "Выпущен: " + sl1.PlanOperDate.ToString("dd.MM.yyyy") + "; Годен до: " + sl1.BBFDate.ToString("dd.MM.yyyy");
                            try
                            {
                                m2.ForeColor = Color.FromName(sl1.Status);
                            }
                            catch (Exception xx)
                            {
                                m2.ForeColor = Color.Violet;
                            }

                            contextMenuStripData.Items.Add(m2);
                        }

                        /*  if (ListBB.Count > 1)
                          {
                              LName = "__________";
                              contextMenuStripData.Items.Add(LName);
                              LName = "Итого: " + (ListBB.Sum(x => x.PlanQuantity)).ToString("N1");
                              contextMenuStripData.Items.Add(LName);
                          }*/
                    }
                    else if (e.ColumnIndex == (13 + Offset))
                    {
                        var sListAA = sListA.Where(x => x.PlanOperDate < DateTime.Today.Date).ToList();
                        var sListAAA = sListAA.GroupBy(x => new { x.OrderNymber, x.MZP, x.PlanOperDate }).
                            Select(g => new PurchTable
                            {
                                PlanOperDate = g.Key.PlanOperDate,
                                OrderNymber = g.Key.OrderNymber,
                                PlanQuantity = g.Sum(x => x.PlanQuantity - x.FactQuantity),
                                Count = g.Count()
                            }).ToList();

                        if (sListAAA.Count > 0)
                        {
                            m1 = new ToolStripMenuItem("Запланированные заявки Навижн");
                            contextMenuStripData.Items.Add(m1);

                            foreach (var sb in sListAAA.OrderBy(x => x.PlanOperDate))
                            {
                                m1 = new ToolStripMenuItem(sb.OrderNymber + " => " + sb.PlanQuantity.ToString("N0"));
                                m1.ToolTipText = "Плановая дата поставки: " + sb.PlanOperDate.ToString("dd.MM.yyyy") + "; К-во: " + sb.Count;
                                m1.ForeColor = Color.DarkRed;

                                contextMenuStripData.Items.Add(m1);
                            }
                        }

                        var sListBBB = sListB.Where(x => x.PlanOperDate < DateTime.Today.Date).ToList();
                        var sListBBB1 = sListBBB.GroupBy(x => new { x.OrderNymber, x.MZP, x.PlanOperDate }).
                            Select(g => new PurchTable
                            {
                                PlanOperDate = g.Key.PlanOperDate,
                                LostDescr = g.Key.MZP,
                                OrderNymber = g.Key.OrderNymber,
                                PlanQuantity = g.Sum(x => x.PlanQuantity - x.FactQuantity),
                                Count = g.Count()
                            }).ToList();
                        if (sListBBB1.Count > 0)
                        {
                            m1 = new ToolStripMenuItem("Рабочие заявки Навижн");
                            contextMenuStripData.Items.Add(m1);

                            foreach (var sb in sListBBB1.OrderBy(x => x.PlanOperDate))
                            {
                                m1 = new ToolStripMenuItem(sb.OrderNymber + "/" + sb.LostDescr + " => " + sb.PlanQuantity.ToString("N0"));
                                m1.ToolTipText = "Плановая дата поставки: " + sb.PlanOperDate.ToString("dd.MM.yyyy") + "; К-во: " + sb.Count;
                                m1.ForeColor = Color.DarkRed;

                                contextMenuStripData.Items.Add(m1);
                            }
                        }

                        var cList = fm.ContList.Where(x => (x.MaterialCode == ProductCode)).OrderBy(x => x.ExpDT).ToList();
                        cList = cList.Where(x => x.ExpDT < DateTime.Today.Date).ToList();

                        var cListA = cList.GroupBy(x => new { x.LotNo, x.LotDescription, x.ExpDT }).
                            Select(g => new PurchTable
                            {
                                PlanOperDate = g.Key.ExpDT,
                                OrderNymber = g.Key.LotNo,
                                LostDescr = g.Key.LotDescription,
                                PlanQuantity = g.Sum(x => x.Quantity),
                                Count = g.Count()
                            }).ToList();

                        if (cListA.Count > 0)
                        {
                            m1 = new ToolStripMenuItem("Лоты/Контейнера");
                            contextMenuStripData.Items.Add(m1);

                            foreach (var c in cListA.OrderBy(x => x.PlanOperDate))
                            {
                                m1 = new ToolStripMenuItem(c.OrderNymber + "/" + c.LostDescr + " => " + c.PlanQuantity.ToString("N0"));
                                m1.ToolTipText = "Плановая дата поставки: " + c.PlanOperDate.ToString("dd.MM.yyyy") + "; К-во: " + c.Count;
                                m1.ForeColor = Color.DarkRed;

                                contextMenuStripData.Items.Add(m1);
                            }
                        }
                    }
                }
                else
                {
                    cf.UserSelectedCode = dataGridViewMain.Rows[e.RowIndex].Cells[0].Value.ToString();
                    if (ColIndex > 0)
                    {
                        ToolStripMenuItem m1;
                        Int32 Offset = cf.WorkMonthList.Count;  //14

                        if (e.ColumnIndex > 13 + Offset)
                        {
                            if (ColIndex > 0)
                            {
                                if ((dataGridViewMain.Columns[ColIndex].HeaderText.Contains("Остаток на")) || (dataGridViewMain.Columns[ColIndex].HeaderText.Contains("Потребление на")) || ((dataGridViewMain.Columns[ColIndex].HeaderText.Contains("Дефицит на"))))
                                {
                                    LName = dataGridViewMain.Columns[e.ColumnIndex].HeaderText;
                                    LName = LName.Substring(LName.Length - 11, 11).Trim();
                                    dt = fm.ConvertDataToDate(LName);
                                }
                                else
                                {
                                    dt = DateTime.Today.Date;
                                }
                            }
                            else
                            {
                                dt = DateTime.Today.Date;
                            }

                            Total = 0;
                            var dll = cf.XLDataList.Where(x => (x.ProdCode == dataGridViewMain.Rows[e.RowIndex].Cells[0].Value.ToString()) && (x.DateWork.Date == dt)).ToList();
                            foreach (var dl in dll)
                            {
                                Total = Total + dl.Quantity;
                            }

                            m1 = new ToolStripMenuItem(Total.ToString("N0"));
                            contextMenuStripData.Items.Add(m1);

                            if (dll.Count > 1)
                            {
                                LName = "__________";
                                contextMenuStripData.Items.Add(LName);
                                LName = "Итого: " + (dll.Sum(x => x.Quantity)).ToString("N1");
                                contextMenuStripData.Items.Add(LName);
                            }
                        }
                        else if (e.ColumnIndex == (8 + Offset))
                        {
                            var CM = CFMList.Where(x => x.MaterialCode == cf.UserSelectedCode).ToList();

                            if (CM.Count > 0)
                            {
                                foreach (var cl in CM[0].ConsurmptionList)
                                {
                                    m1 = new ToolStripMenuItem(cl.Storage + " => " + cl.Quantity.ToString("N1"));
                                    contextMenuStripData.Items.Add(m1);
                                }
                            }
                        }
                        else if (e.ColumnIndex == (9 + Offset))
                        {
                            var ListAA = sbrMesList.GroupBy(x => new { x.Storage, x.LotName, x.ProdDate, x.BBFDate, x.Status }).
                                         Select(g => new PurchTable
                                         {
                                             PlanOperDate = g.Key.ProdDate,
                                             BBFDate = g.Key.BBFDate,
                                             OrderNymber = g.Key.Storage,
                                             LostDescr = g.Key.LotName,
                                             PlanQuantity = g.Sum(x => x.QuantityStorageDay),
                                             Status = g.Key.Status,
                                             Count = g.Count()
                                         }).ToList();

                            if (cf.cbMaterialDelay.Checked == true)
                            {
                                ListAA = ListAA.Where(x => x.BBFDate >= DateTime.Today.Date).ToList();
                            }

                            foreach (var sml in ListAA.OrderBy(x => x.PlanOperDate)) //sbrMesList)
                            {
                                m1 = new ToolStripMenuItem(sml.OrderNymber + " [" + sml.LostDescr + "] => " + sml.PlanQuantity.ToString("N1"));
                                m1.ToolTipText = "Выпущен: " + sml.PlanOperDate.ToString("dd.MM.yyyy") + "; Годен до: " + sml.BBFDate.ToString("dd.MM.yyyy"); // +"; К-во: "+sml.Count.ToString();
                                try
                                {
                                    m1.ForeColor = Color.FromName(sml.Status);
                                }
                                catch (Exception xx)
                                {
                                    m1.ForeColor = Color.Violet;
                                }

                                contextMenuStripData.Items.Add(m1);
                            }
                        }
                        else if (e.ColumnIndex == (10 + Offset))
                        {
                            var ListBB = sbpList.GroupBy(x => new { x.LineName, x.MaterialLotName, x.ValidFrom, x.ValidTo, x.Status }).
                                        Select(g => new PurchTable
                                        {
                                            OrderNymber = g.Key.LineName,
                                            LostDescr = g.Key.MaterialLotName,
                                            PlanQuantity = g.Sum(x => x.Quantity),
                                            PlanOperDate = g.Key.ValidFrom,
                                            BBFDate = g.Key.ValidTo,
                                            Status = g.Key.Status,
                                            Count = g.Count()
                                        }).ToList();

                            if (cf.cbMaterialDelay.Checked == true)
                            {
                                ListBB = ListBB.Where(x => x.BBFDate >= DateTime.Today.Date).ToList();
                            }

                            foreach (var sl1 in ListBB.OrderBy(x => x.PlanOperDate)) //sbpList)
                            {
                                ToolStripMenuItem m2 = new ToolStripMenuItem(sl1.OrderNymber + " [" + sl1.LostDescr + "] => " + sl1.PlanQuantity.ToString("N1"));
                                //      m2.ToolTipText = "Количество записей: " + sl1.Count.ToString();
                                m2.ToolTipText = "Выпущен: " + sl1.PlanOperDate.ToString("dd.MM.yyyy") + "; Годен до: " + sl1.BBFDate.ToString("dd.MM.yyyy");
                                try
                                {
                                    m2.ForeColor = Color.FromName(sl1.Status);
                                }
                                catch (Exception xx)
                                {
                                    m2.ForeColor = Color.Violet;
                                }

                                contextMenuStripData.Items.Add(m2);
                            }
                        }
                        else if (e.ColumnIndex == (13 + Offset))
                        {
                            var sListAA = sListA.Where(x => x.PlanOperDate < DateTime.Today.Date).ToList();
                            var sListAAA = sListAA.GroupBy(x => new { x.OrderNymber, x.MZP, x.PlanOperDate }).
                                Select(g => new PurchTable
                                {
                                    PlanOperDate = g.Key.PlanOperDate,
                                    OrderNymber = g.Key.OrderNymber,
                                    PlanQuantity = g.Sum(x => x.PlanQuantity - x.FactQuantity),
                                    Count = g.Count()
                                }).ToList();

                            if (sListAAA.Count > 0)
                            {
                                m1 = new ToolStripMenuItem("Запланированные заявки Навижн");
                                contextMenuStripData.Items.Add(m1);

                                foreach (var sb in sListAAA.OrderBy(x => x.PlanOperDate))
                                {
                                    m1 = new ToolStripMenuItem(sb.OrderNymber + " => " + sb.PlanQuantity.ToString("N0"));
                                    m1.ToolTipText = "Плановая дата поставки: " + sb.PlanOperDate.ToString("dd.MM.yyyy") + "; К-во: " + sb.Count;
                                    m1.ForeColor = Color.DarkRed;

                                    contextMenuStripData.Items.Add(m1);
                                }
                            }

                            var sListBBB = sListB.Where(x => x.PlanOperDate < DateTime.Today.Date).ToList();
                            var sListBBB1 = sListBBB.GroupBy(x => new { x.OrderNymber, x.MZP, x.PlanOperDate }).
                                Select(g => new PurchTable
                                {
                                    PlanOperDate = g.Key.PlanOperDate,
                                    LostDescr = g.Key.MZP,
                                    OrderNymber = g.Key.OrderNymber,
                                    PlanQuantity = g.Sum(x => x.PlanQuantity - x.FactQuantity),
                                    Count = g.Count()
                                }).ToList();
                            if (sListBBB1.Count > 0)
                            {
                                m1 = new ToolStripMenuItem("Рабочие заявки Навижн");
                                contextMenuStripData.Items.Add(m1);

                                foreach (var sb in sListBBB1.OrderBy(x => x.PlanOperDate))
                                {
                                    m1 = new ToolStripMenuItem(sb.OrderNymber + "/" + sb.LostDescr + " => " + sb.PlanQuantity.ToString("N0"));
                                    m1.ToolTipText = "Плановая дата поставки: " + sb.PlanOperDate.ToString("dd.MM.yyyy") + "; К-во: " + sb.Count;
                                    m1.ForeColor = Color.DarkRed;

                                    contextMenuStripData.Items.Add(m1);
                                }
                            }

                            var cList = fm.ContList.Where(x => (x.MaterialCode == ProductCode)).OrderBy(x => x.ExpDT).ToList();
                            cList = cList.Where(x => x.ExpDT < DateTime.Today.Date).ToList();

                            var cListA = cList.GroupBy(x => new { x.LotNo, x.LotDescription, x.ExpDT }).
                                Select(g => new PurchTable
                                {
                                    PlanOperDate = g.Key.ExpDT,
                                    OrderNymber = g.Key.LotNo,
                                    LostDescr = g.Key.LotDescription,
                                    PlanQuantity = g.Sum(x => x.Quantity),
                                    Count = g.Count()
                                }).ToList();

                            if (cListA.Count > 0)
                            {
                                m1 = new ToolStripMenuItem("Лоты/Контейнера");
                                contextMenuStripData.Items.Add(m1);

                                foreach (var c in cListA.OrderBy(x => x.PlanOperDate))
                                {
                                    m1 = new ToolStripMenuItem(c.OrderNymber + "/" + c.LostDescr + " => " + c.PlanQuantity.ToString("N0"));
                                    m1.ToolTipText = "Плановая дата поставки: " + c.PlanOperDate.ToString("dd.MM.yyyy") + "; К-во: " + c.Count;
                                    m1.ForeColor = Color.DarkRed;

                                    contextMenuStripData.Items.Add(m1);
                                }
                            }
                        }
                    }
                }
                contextMenuStripData.Show(AxX, AxY);

            }  //rowInd, ColInd

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            Cursor = Cursors.Default;
        }

        private void dgvStorages_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (dgvStorages.RowCount > 0)
            {
                foreach (DataGridViewRow r in dgvStorages.Rows)
                {
                    Color cColor;
                    try
                    {
                        cColor = Color.FromName(r.Cells[5].Value.ToString());
                    }
                    catch (Exception xx)
                    {
                        cColor = Color.Black;
                    }

                    foreach (DataGridViewCell c in r.Cells)
                    {
                        c.Style.ForeColor = cColor;
                    }
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (dataGridViewMain.RowCount > 0)
            {
                Cursor = Cursors.WaitCursor;
                double Value;
                string sVal;
                double T1;
                double T2;
                double Q = 0;
                Int32 Cols = cf.WorkMonthList.Count;
                Int32 CurCol = 14 + cf.WorkMonthList.Count;
                DateTime WorkDate;
                List<DateTime> WorkDateList = new List<DateTime>();
                Int32 Interval;

                Excel1.Application xlApp = new Excel1.Application();
                xlApp.Visible = true;
                object misValue = System.Reflection.Missing.Value;

                Excel1.Workbook wBook = xlApp.Workbooks.Add(misValue);
                xlApp.DisplayAlerts = false;
                Excel1.Worksheet wSheet = (Excel1.Worksheet)wBook.Sheets[1];

                wSheet.Name = "Остатки с МЗП";
                Excel1.Range range1;

                List<DateTime> DTList1 = new List<DateTime>();
                DTList1 = cf.DTList;
                if (cf.cbDontShowAfter.Checked == true)
                {
                    var XLD = fm.ExcelDataList[cf.comboBoxFiltering.SelectedIndex];
                    DateTime LimitDate = XLD.DateWork;
                    DTList1 = (from d in DTList1
                               where d <= LimitDate
                               select d).ToList();
                }

                for (int i = 0; i < dataGridViewMain.Columns.Count - 1; i++)
                {
                    wSheet.Cells[1, i + 1] = dataGridViewMain.Columns[i].HeaderText;
                }

                range1 = wSheet.Cells[1, 1] as Excel1.Range;
                range1.ColumnWidth = 15;
                range1 = wSheet.Cells[1, 2] as Excel1.Range;
                range1.ColumnWidth = 50;
                range1 = wSheet.Cells[1, 3] as Excel1.Range;
                range1.ColumnWidth = 30;

                range1 = wSheet.Range[wSheet.Cells[1, 1], wSheet.Cells[1, dataGridViewMain.Columns.Count - 1]];
                range1.Font.Bold = true;
                range1.WrapText = true;
                range1.HorizontalAlignment = Excel1.XlHAlign.xlHAlignCenter;
                range1.VerticalAlignment = Excel1.XlVAlign.xlVAlignCenter;

                range1 = wSheet.Range[wSheet.Cells[2, 1], wSheet.Cells[CFMList.Count + 1, 1]];
                range1.NumberFormat = "@";

                for (int i = 0; i < CFMList.Count; i++)
                {
                    wSheet.Cells[i + 2, 1] = CFMList[i].MaterialCode;
                    wSheet.Cells[i + 2, 2] = CFMList[i].MaterialName;
                    wSheet.Cells[i + 2, 3] = CFMList[i].MaterialGroup;
                    wSheet.Cells[i + 2, 4] = CFMList[i].MaterialMultiply;
                    wSheet.Cells[i + 2, 5] = CFMList[i].WaitingDays;
                    wSheet.Cells[i + 2, 6] = CFMList[i].StorageQuantity;
                    wSheet.Cells[i + 2, 7] = CFMList[i].Responsible;
                    wSheet.Cells[i + 2, 8] = CFMList[i].Sender;

                    for (int j = 0; j < Cols; j++)
                    {
                        wSheet.Cells[i + 2, 9 + j] = Math.Round(CFMList[i].OutList[j].Quantity, 0);
                    }

                    wSheet.Cells[i + 2, 9 + Cols] = Math.Round(CFMList[i].CurrentConsumption, 0);
                    wSheet.Cells[i + 2, 10 + Cols] = Math.Round(CFMList[i].RawStorage, 0);
                    wSheet.Cells[i + 2, 11 + Cols] = Math.Round(CFMList[i].RawEnterprise, 0);
                    wSheet.Cells[i + 2, 12 + Cols] = CFMList[i].RawNav1.ToString("N0") + "(" + CFMList[i].RawNav2.ToString("N0") + ")";
                    wSheet.Cells[i + 2, 13 + Cols] = CFMList[i].RawMesOut2.ToString("N0") + "(" + CFMList[i].RawMesOut1.ToString("N0") + ")";
                    wSheet.Cells[i + 2, 14 + Cols] = Math.Round(CFMList[i].OldTaskNav, 0);

                    Value = 0;

                    foreach (var sl in CFMList[i].RawStorageList)
                    {
                        Value = Value + sl.Quantity;
                    }

                    foreach (var el in CFMList[i].RawEnterpriseList)
                    {
                        Value = Value + el.Quantity;
                    }

                    for (int j = 0; j < DTList1.Count; j++)
                    {
                        T2 = 0;
                        var FDTList = DTList1.Where(x => (x.Month == DTList1[j].Month) && (x.Year == DTList1[j].Year)).ToList();
                        //income
                        var tData2 = CFMList[i].TaskNavList2.Where(x => x.BBFDate == DTList1[j].Date).ToList();
                        if ((DTList1[j].Day == 1) && (FDTList.Count == 1) && (tData2.Count == 0))
                        {
                            tData2 = CFMList[i].TaskNavList2.Where(x => x.AlterDate == DTList1[j]).ToList();
                        }

                        foreach (var td2 in tData2)
                        {
                            T2 = T2 + td2.Quantity;
                        }

                        var Cdata = fm.ContList.Where(x => (x.MaterialCode == CFMList[i].MaterialCode) && (x.ExpDT.Date == DTList1[j].Date)).ToList();
                        if ((DTList1[j].Day == 1) && (FDTList.Count == 1) && (Cdata.Count == 0))
                        {
                            Cdata = fm.ContList.Where(x => (x.MaterialCode == CFMList[i].MaterialCode) && (((DateTime)x.AlterDate).Date == DTList1[j].Date)).ToList();
                        }

                        foreach (var cd in Cdata)
                        {
                            T2 = T2 + cd.Quantity;
                        }
                        Value = Value + T2;
                        //ask in progress
                        var tData1 = CFMList[i].TaskNavList1.Where(x => x.BBFDate == DTList1[j].Date).ToList();
                        if ((DTList1[j].Day == 1) && (FDTList.Count == 1) && (tData1.Count == 0))
                        {
                            tData1 = CFMList[i].TaskNavList1.Where(x => x.AlterDate == DTList1[j]).ToList();
                        }

                        T1 = 0;
                        foreach (var td1 in tData1)
                        {
                            T1 = T1 + td1.Quantity;
                        }
                        Value = Value + T1;
                        //credit
                        var dll = cf.XLDataList.Where(x => (x.ProdCode == CFMList[i].MaterialCode) && (x.DateWork.Date == DTList1[j].Date)).ToList();
                        foreach (var dl in dll)
                        {
                            Value = Value - dl.Quantity;
                        }

                        Q = 0;
                        var adata = cf.AppList.Where(x => (x.MaterialCode == CFMList[i].MaterialCode) && (x.DateWork.Date == DTList1[j].Date)).ToList();
                        if ((adata.Count == 0) && (FDTList.Count == 1) && (DTList1[j].Day == 1))
                        {
                            adata = cf.AppList;
                            adata = adata.Where(x => x.MaterialCode == CFMList[i].MaterialCode).ToList();
                            adata = adata.Where(x => (DateTime)x.AlterDate == DTList1[j].Date).ToList();
                        }

                        foreach (var ad in adata)
                        {
                            Q = Q + ad.Quantity;
                        }

                        if (Value < 0)
                        {
                            wSheet.Cells[i + 2, CurCol + j] = Math.Round(Value, 0);
                            range1 = wSheet.Cells[i + 2, CurCol + j] as Excel1.Range;
                            range1.Font.Bold = true;
                            range1.Font.Color = Color.Red;    //Color.DarkRed;
                        }
                        else
                        {
                            if ((T1 > 0) || (T2 > 0) || (Q > 0))
                            {
                                sVal = Value.ToString("N0");

                                /*  if (T1>0)
                                  {
                                      sVal=sVal+" ["+ T1.ToString("N0") + "]";
                                  }*/
                                if ((T2 > 0) || (T1 > 0))
                                {
                                    sVal = sVal + " (" + (T2 + T1).ToString("N0") + ")";
                                }
                                if (Q > 0)
                                {
                                    sVal = sVal + " {" + T2.ToString("N0") + "}";
                                }
                                wSheet.Cells[i + 2, CurCol + j] = sVal;
                            }
                            else
                            {
                                wSheet.Cells[i + 2, CurCol + j] = Math.Round(Value, 0);
                            }
                        }
                    }
                }  //остаток

                wSheet = (Excel1.Worksheet)wBook.Sheets.Add(After: wBook.ActiveSheet);
                wSheet.Name = "Остатки без МЗП";

                for (int i = 0; i < dataGridViewMain.Columns.Count - 1; i++)
                {
                    wSheet.Cells[1, i + 1] = dataGridViewMain.Columns[i].HeaderText;
                }

                range1 = wSheet.Cells[1, 1] as Excel1.Range;
                range1.ColumnWidth = 20;
                range1 = wSheet.Cells[1, 2] as Excel1.Range;
                range1.ColumnWidth = 50;
                range1 = wSheet.Cells[1, 3] as Excel1.Range;
                range1.ColumnWidth = 30;

                range1 = wSheet.Range[wSheet.Cells[1, 1], wSheet.Cells[1, dataGridViewMain.Columns.Count - 1]];
                range1.Font.Bold = true;
                range1.WrapText = true;
                range1.HorizontalAlignment = Excel1.XlHAlign.xlHAlignCenter;
                range1.VerticalAlignment = Excel1.XlVAlign.xlVAlignCenter;

                range1 = wSheet.Range[wSheet.Cells[2, 1], wSheet.Cells[CFMList.Count + 1, 1]];
                range1.NumberFormat = "@";

                for (int i = 0; i < CFMList.Count; i++)
                {
                    wSheet.Cells[i + 2, 1] = CFMList[i].MaterialCode;
                    wSheet.Cells[i + 2, 2] = CFMList[i].MaterialName;
                    wSheet.Cells[i + 2, 3] = CFMList[i].MaterialGroup;
                    wSheet.Cells[i + 2, 4] = CFMList[i].MaterialMultiply;
                    wSheet.Cells[i + 2, 5] = CFMList[i].WaitingDays;
                    wSheet.Cells[i + 2, 6] = CFMList[i].StorageQuantity;
                    wSheet.Cells[i + 2, 7] = CFMList[i].Responsible;
                    wSheet.Cells[i + 2, 8] = CFMList[i].Sender;

                    for (int j = 0; j < Cols; j++)
                    {
                        wSheet.Cells[i + 2, 9 + j] = Math.Round(CFMList[i].OutList[j].Quantity, 0);
                    }

                    wSheet.Cells[i + 2, 9 + Cols] = Math.Round(CFMList[i].CurrentConsumption, 0);
                    wSheet.Cells[i + 2, 10 + Cols] = Math.Round(CFMList[i].RawStorage, 0);
                    wSheet.Cells[i + 2, 11 + Cols] = Math.Round(CFMList[i].RawEnterprise, 0);
                    wSheet.Cells[i + 2, 12 + Cols] = CFMList[i].RawNav1.ToString("N0") + "(" + CFMList[i].RawNav2.ToString("N0") + ")";
                    wSheet.Cells[i + 2, 13 + Cols] = CFMList[i].RawMesOut2.ToString("N0") + "(" + CFMList[i].RawMesOut1.ToString("N0") + ")";
                    wSheet.Cells[i + 2, 14 + Cols] = Math.Round(CFMList[i].OldTaskNav, 0);

                    /*   wSheet.Cells[i + 2, 9 + Cols] = Math.Round(CFMList[i].RawStorage, 0);
                       wSheet.Cells[i + 2, 10 + Cols] = Math.Round(CFMList[i].RawEnterprise, 0);
                       wSheet.Cells[i + 2, 11 + Cols] = CFMList[i].RawNav1.ToString("N0") + "(" + CFMList[i].RawNav2.ToString("N0") + ")";
                       wSheet.Cells[i + 2, 12 + Cols] = CFMList[i].RawMesOut2.ToString("N0") + "(" + CFMList[i].RawMesOut1.ToString("N0") + ")";
                       wSheet.Cells[i + 2, 13 + Cols] = Math.Round(CFMList[i].OldTaskNav, 0);*/

                    Value = 0;

                    foreach (var sl in CFMList[i].RawStorageList)
                    {
                        Value = Value + sl.Quantity;
                    }

                    foreach (var el in CFMList[i].RawEnterpriseList)
                    {
                        Value = Value + el.Quantity;
                    }

                    for (int j = 0; j < DTList1.Count; j++)
                    {
                        //credit
                        var dll = cf.XLDataList.Where(x => (x.ProdCode == CFMList[i].MaterialCode) && (x.DateWork.Date == DTList1[j].Date)).ToList();
                        foreach (var dl in dll)
                        {
                            Value = Value - dl.Quantity;
                        }

                        wSheet.Cells[i + 2, CurCol + j] = Math.Round(Value, 0);

                        if (Value < 0)
                        {
                            range1 = wSheet.Cells[i + 2, CurCol + j] as Excel1.Range;
                            range1.Font.Bold = true;
                            range1.Font.Color = Color.Red; //Color.DarkRed;
                        }
                    }
                }  //остаток2
                wSheet = (Excel1.Worksheet)wBook.Sheets.Add(After: wBook.ActiveSheet);
                wSheet.Name = "Дефицит";

                for (int i = 0; i < dataGridViewMain.Columns.Count - 1; i++)
                {
                    wSheet.Cells[1, i + 1] = dataGridViewMain.Columns[i].HeaderText;
                }

                range1 = wSheet.Cells[1, 1] as Excel1.Range;
                range1.ColumnWidth = 20;
                range1 = wSheet.Cells[1, 2] as Excel1.Range;
                range1.ColumnWidth = 50;
                range1 = wSheet.Cells[1, 3] as Excel1.Range;
                range1.ColumnWidth = 30;

                range1 = wSheet.Range[wSheet.Cells[1, 1], wSheet.Cells[1, dataGridViewMain.Columns.Count - 1]];
                range1.Font.Bold = true;
                range1.WrapText = true;
                range1.HorizontalAlignment = Excel1.XlHAlign.xlHAlignCenter;
                range1.VerticalAlignment = Excel1.XlVAlign.xlVAlignCenter;

                range1 = wSheet.Range[wSheet.Cells[2, 1], wSheet.Cells[CFMList.Count + 1, 1]];
                range1.NumberFormat = "@";

                for (int i = 0; i < CFMList.Count; i++)
                {
                    wSheet.Cells[i + 2, 1] = CFMList[i].MaterialCode;
                    wSheet.Cells[i + 2, 2] = CFMList[i].MaterialName;
                    wSheet.Cells[i + 2, 3] = CFMList[i].MaterialGroup;
                    wSheet.Cells[i + 2, 4] = CFMList[i].MaterialMultiply;
                    wSheet.Cells[i + 2, 5] = CFMList[i].WaitingDays;
                    wSheet.Cells[i + 2, 6] = CFMList[i].StorageQuantity;
                    wSheet.Cells[i + 2, 7] = CFMList[i].Responsible;
                    wSheet.Cells[i + 2, 8] = CFMList[i].Sender;

                    for (int j = 0; j < Cols; j++)
                    {
                        wSheet.Cells[i + 2, 9 + j] = Math.Round(CFMList[i].OutList[j].Quantity, 0);
                    }

                    wSheet.Cells[i + 2, 9 + Cols] = Math.Round(CFMList[i].CurrentConsumption, 0);
                    wSheet.Cells[i + 2, 10 + Cols] = Math.Round(CFMList[i].RawStorage, 0);
                    wSheet.Cells[i + 2, 11 + Cols] = Math.Round(CFMList[i].RawEnterprise, 0);
                    wSheet.Cells[i + 2, 12 + Cols] = CFMList[i].RawNav1.ToString("N0") + "(" + CFMList[i].RawNav2.ToString("N0") + ")";
                    wSheet.Cells[i + 2, 13 + Cols] = CFMList[i].RawMesOut2.ToString("N0") + "(" + CFMList[i].RawMesOut1.ToString("N0") + ")";
                    wSheet.Cells[i + 2, 14 + Cols] = Math.Round(CFMList[i].OldTaskNav, 0);

                    /*wSheet.Cells[i + 2, 9 + Cols] = Math.Round(CFMList[i].RawStorage, 0);
                    wSheet.Cells[i + 2, 10 + Cols] = Math.Round(CFMList[i].RawEnterprise, 0);
                    wSheet.Cells[i + 2, 11 + Cols] = CFMList[i].RawNav1.ToString("N0") + "(" + CFMList[i].RawNav2.ToString("N0") + ")";
                    wSheet.Cells[i + 2, 12 + Cols] = CFMList[i].RawMesOut2.ToString("N0") + "(" + CFMList[i].RawMesOut1.ToString("N0") + ")";
                    wSheet.Cells[i + 2, 13 + Cols] = Math.Round(CFMList[i].OldTaskNav, 0);*/

                    Value = 0;

                    foreach (var sl in CFMList[i].RawStorageList)
                    {
                        Value = Value + sl.Quantity;
                    }

                    foreach (var el in CFMList[i].RawEnterpriseList)
                    {
                        Value = Value + el.Quantity;
                    }

                    for (int j = 0; j < DTList1.Count; j++)
                    {
                        T2 = 0;
                        var FDTList = DTList1.Where(x => (x.Month == DTList1[j].Month) && (x.Year == DTList1[j].Year)).ToList();
                        //income
                        var tData2 = CFMList[i].TaskNavList2.Where(x => x.BBFDate == DTList1[j].Date).ToList();
                        if ((DTList1[j].Day == 1) && (FDTList.Count == 1) && (tData2.Count == 0))
                        {
                            tData2 = CFMList[i].TaskNavList2.Where(x => x.AlterDate == DTList1[j]).ToList();
                        }

                        foreach (var td2 in tData2)
                        {
                            T2 = T2 + td2.Quantity;
                        }

                        var Cdata = fm.ContList.Where(x => (x.MaterialCode == CFMList[i].MaterialCode) && (x.ExpDT.Date == DTList1[j].Date)).ToList();
                        if ((DTList1[j].Day == 1) && (FDTList.Count == 1) && (Cdata.Count == 0))
                        {
                            Cdata = fm.ContList.Where(x => (x.MaterialCode == CFMList[i].MaterialCode) && (((DateTime)x.AlterDate).Date == DTList1[j].Date)).ToList();
                        }

                        foreach (var cd in Cdata)
                        {
                            T2 = T2 + cd.Quantity;
                        }

                        Value = Value + T2;
                        //ask in progress
                        var tData1 = CFMList[i].TaskNavList1.Where(x => x.BBFDate == DTList1[j].Date).ToList();
                        if ((DTList1[j].Day == 1) && (FDTList.Count == 1) && (tData1.Count == 0))
                        {
                            tData1 = CFMList[i].TaskNavList1.Where(x => x.AlterDate == DTList1[j]).ToList();
                        }

                        T1 = 0;
                        foreach (var td1 in tData1)
                        {
                            T1 = T1 + td1.Quantity;
                        }
                        Value = Value + T1;

                        //credit
                        var dll = cf.XLDataList.Where(x => (x.ProdCode == CFMList[i].MaterialCode) && (x.DateWork.Date == DTList1[j].Date)).ToList();
                        foreach (var dl in dll)
                        {
                            Value = Value - dl.Quantity;
                        }

                        if (Value < 0)
                        {
                            wSheet.Cells[i + 2, CurCol + j] = Math.Round(-1 * Value, 0);
                        }
                        else
                        { }
                    }
                }  //дефицит

                wSheet = (Excel1.Worksheet)wBook.Sheets.Add(After: wBook.ActiveSheet);
                wSheet.Name = "Потребление";

                for (int i = 0; i < dataGridViewMain.Columns.Count - 1; i++)
                {
                    wSheet.Cells[1, i + 1] = dataGridViewMain.Columns[i].HeaderText;
                }

                range1 = wSheet.Cells[1, 1] as Excel1.Range;
                range1.ColumnWidth = 20;
                range1 = wSheet.Cells[1, 2] as Excel1.Range;
                range1.ColumnWidth = 50;
                range1 = wSheet.Cells[1, 3] as Excel1.Range;
                range1.ColumnWidth = 30;

                range1 = wSheet.Range[wSheet.Cells[1, 1], wSheet.Cells[1, dataGridViewMain.Columns.Count - 1]];
                range1.Font.Bold = true;
                range1.WrapText = true;
                range1.HorizontalAlignment = Excel1.XlHAlign.xlHAlignCenter;
                range1.VerticalAlignment = Excel1.XlVAlign.xlVAlignCenter;

                range1 = wSheet.Range[wSheet.Cells[2, 1], wSheet.Cells[CFMList.Count + 1, 1]];
                range1.NumberFormat = "@";

                for (int i = 0; i < CFMList.Count; i++)
                {
                    wSheet.Cells[i + 2, 1] = CFMList[i].MaterialCode;
                    wSheet.Cells[i + 2, 2] = CFMList[i].MaterialName;
                    wSheet.Cells[i + 2, 3] = CFMList[i].MaterialGroup;
                    wSheet.Cells[i + 2, 4] = CFMList[i].MaterialMultiply;
                    wSheet.Cells[i + 2, 5] = CFMList[i].WaitingDays;
                    wSheet.Cells[i + 2, 6] = CFMList[i].StorageQuantity;
                    wSheet.Cells[i + 2, 7] = CFMList[i].Responsible;
                    wSheet.Cells[i + 2, 8] = CFMList[i].Sender;

                    for (int j = 0; j < Cols; j++)
                    {
                        wSheet.Cells[i + 2, 9 + j] = Math.Round(CFMList[i].OutList[j].Quantity, 0);
                    }

                    wSheet.Cells[i + 2, 9 + Cols] = Math.Round(CFMList[i].CurrentConsumption, 0);
                    wSheet.Cells[i + 2, 10 + Cols] = Math.Round(CFMList[i].RawStorage, 0);
                    wSheet.Cells[i + 2, 11 + Cols] = Math.Round(CFMList[i].RawEnterprise, 0);
                    wSheet.Cells[i + 2, 12 + Cols] = CFMList[i].RawNav1.ToString("N0") + "(" + CFMList[i].RawNav2.ToString("N0") + ")";
                    wSheet.Cells[i + 2, 13 + Cols] = CFMList[i].RawMesOut2.ToString("N0") + "(" + CFMList[i].RawMesOut1.ToString("N0") + ")";
                    wSheet.Cells[i + 2, 14 + Cols] = Math.Round(CFMList[i].OldTaskNav, 0);

                    /*wSheet.Cells[i + 2, 9 + Cols] = Math.Round(CFMList[i].RawStorage, 0);
                    wSheet.Cells[i + 2, 10 + Cols] = Math.Round(CFMList[i].RawEnterprise, 0);
                    wSheet.Cells[i + 2, 11 + Cols] = CFMList[i].RawNav1.ToString("N0") + "(" + CFMList[i].RawNav2.ToString("N0") + ")";
                    wSheet.Cells[i + 2, 12 + Cols] = CFMList[i].RawMesOut2.ToString("N0") + "(" + CFMList[i].RawMesOut1.ToString("N0") + ")";
                    wSheet.Cells[i + 2, 13 + Cols] = Math.Round(CFMList[i].OldTaskNav, 0);*/

                    for (int j = 0; j < DTList1.Count; j++)
                    {
                        Value = 0;
                        //credit
                        var dll = cf.XLDataList.Where(x => (x.ProdCode == CFMList[i].MaterialCode) && (x.DateWork.Date == DTList1[j].Date)).ToList();
                        foreach (var dl in dll)
                        {
                            Value = Value + dl.Quantity;
                        }

                        if (Value > 0)
                        {
                            wSheet.Cells[i + 2, CurCol + j] = Math.Round(Value, 0);
                        }
                    }
                }  //потребление

                wSheet = (Excel1.Worksheet)wBook.Sheets.Add(After: wBook.ActiveSheet);
                wSheet.Name = "ОПР";

                WorkDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                WorkDate = WorkDate.AddMonths(-1);
                WorkDateList.Add(WorkDate);
                WorkDate = WorkDate.AddMonths(-1);
                WorkDateList.Insert(0, WorkDate);
                WorkDate = WorkDate.AddMonths(-1);
                WorkDateList.Insert(0, WorkDate);

                wSheet.Cells[1, 1] = "Код Материала";
                wSheet.Cells[1, 2] = "Наименование";
                wSheet.Cells[1, 3] = "Срок поставки";
                wSheet.Cells[1, 4] = "Кратность поставки";
                wSheet.Cells[1, 5] = "Месячное потребление " + WorkDateList[0].ToString("MM.yyyy");
                wSheet.Cells[1, 6] = "Месячное потребление " + WorkDateList[1].ToString("MM.yyyy");
                wSheet.Cells[1, 7] = "Месячное потребление " + WorkDateList[2].ToString("MM.yyyy");
                wSheet.Cells[1, 8] = "Среднее";
                wSheet.Cells[1, 9] = "Остатки Склад";
                wSheet.Cells[1, 10] = "Остатки Производство";
                wSheet.Cells[1, 11] = "Остатки Внешние";
                wSheet.Cells[1, 12] = "Итого, Остаток";
                wSheet.Cells[1, 13] = "Остатков хватит, дней";

                range1 = wSheet.Cells[1, 1] as Excel1.Range;
                range1.ColumnWidth = 20;
                range1 = wSheet.Cells[1, 2] as Excel1.Range;
                range1.ColumnWidth = 50;

                range1 = wSheet.Range[wSheet.Cells[1, 1], wSheet.Cells[1, 13]];
                range1.Font.Bold = true;
                range1.WrapText = true;
                range1.HorizontalAlignment = Excel1.XlHAlign.xlHAlignCenter;
                range1.VerticalAlignment = Excel1.XlVAlign.xlVAlignCenter;

                range1 = wSheet.Range[wSheet.Cells[2, 1], wSheet.Cells[fm.OPRList.Count + 1, 1]];
                range1.NumberFormat = "@";

                var Clist = CFMList.Where(x => fm.OPRList.Contains(x.MaterialCode)).ToList();
                WorkDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                Interval = DateTime.Today.Date.Subtract(WorkDate).Days;

                for (int i = 0; i < Clist.Count; i++)
                {
                    wSheet.Cells[i + 2, 1] = Clist[i].MaterialCode;
                    wSheet.Cells[i + 2, 2] = Clist[i].MaterialName;
                    wSheet.Cells[i + 2, 3] = Clist[i].WaitingDays;
                    wSheet.Cells[i + 2, 4] = Clist[i].StorageQuantity;

                    var OList = Clist[i].OutList.Where(x => x.ProdDate == WorkDateList[0]).ToList();
                    Value = 0;

                    if (OList.Count > 0)
                    {
                        Value = OList.Sum(x => x.Quantity);
                        wSheet.Cells[i + 2, 5] = Value;
                    }

                    OList = Clist[i].OutList.Where(x => x.ProdDate == WorkDateList[1]).ToList();
                    if (OList.Count > 0)
                    {
                        Value = Value + OList.Sum(x => x.Quantity);
                        wSheet.Cells[i + 2, 6] = OList.Sum(x => x.Quantity);
                    }

                    OList = Clist[i].OutList.Where(x => x.ProdDate == WorkDateList[2]).ToList();
                    if (OList.Count > 0)
                    {
                        Value = Value + OList.Sum(x => x.Quantity);
                        wSheet.Cells[i + 2, 7] = OList.Sum(x => x.Quantity);
                    }

                    T2 = 0;
                    Value = Value / 3.0;
                    wSheet.Cells[i + 2, 8] = Math.Round(Value);
                    wSheet.Cells[i + 2, 9] = Math.Round(Clist[i].RawStorage, 0);
                    T2 = Clist[i].RawStorage;
                    wSheet.Cells[i + 2, 10] = Math.Round(Clist[i].RawEnterprise, 0);
                    T2 = T2 + Clist[i].RawEnterprise;
                    wSheet.Cells[i + 2, 11] = Math.Round(Clist[i].RawNav1);
                    T2 = T2 + Clist[i].RawNav1;
                    wSheet.Cells[i + 2, 12] = Math.Round(T2, 0);

                    Value = (T2 * 30 / Value) - Interval;
                    wSheet.Cells[i + 2, 13] = Math.Round(Value, 0);
                }//OPR

                //  List<string> OPRList = new List<string>();

                var OPRListNames = fm.OPRList.Except(Clist.Select(x => x.MaterialCode).ToList()).ToList();
                Int32 Offer = Clist.Count + 5;
                var OprList = fm.tdb.PlanOPZList.Where(x => (bool)x.IsBase != true).ToList();    // fm.helg.PlanOPZList.ToList();
                OprList = OprList.Where(x => OPRListNames.Contains(x.MatCode)).ToList();

                range1 = wSheet.Range[wSheet.Cells[Offer, 1], wSheet.Cells[OprList.Count + Offer + 1, 1]];
                range1.NumberFormat = "@";

                for (int i = 0; i < OprList.Count; i++)
                {
                    wSheet.Cells[i + Offer, 1] = OprList[i].MatCode;
                    wSheet.Cells[i + Offer, 2] = OprList[i].MatName;

                    T2 = 0;
                    var dData = fm.StockBaklanceList.Where(x => x.WorkDate.Date == DateTime.Today.Date && x.MaterialCode == OprList[i].MatCode).ToList();
                    T2 = dData.Sum(x => (double)x.Quantity);  //storage
                    wSheet.Cells[i + Offer, 9] = T2;

                    var dData1 = fm.StockBalancesPlantList.Where(x => x.WorkDate.Date == DateTime.Today.Date && x.MaterialCode == OprList[i].MatCode).ToList();
                    T2 = T2 + dData1.Sum(x => x.Quantity);
                    wSheet.Cells[i + Offer, 10] = dData1.Sum(x => x.Quantity);  //Plant

                    var dData2 = fm.StockBalancesMesList.Where(x => x.WorkDate.Date == DateTime.Today.Date && x.MaterialCode == OprList[i].MatCode).ToList();
                    T2 = T2 + dData2.Sum(x => x.Quantity);
                    wSheet.Cells[i + Offer, 11] = dData2.Sum(x => x.Quantity);  //mes

                    wSheet.Cells[i + Offer, 12] = T2;
                }

                wSheet = null;
                wBook = null;
                range1 = null;
                //   xlApp.Quit();
                xlApp = null;

                MessageBox.Show("Отчет сформирован", "Сообщение системы");
            }

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            Cursor = Cursors.Default;
        }

        private void cbMaterialDelay_CheckedChanged(object sender, EventArgs e)
        {
            panel4.Enabled = false;
            ShowData();
            DrawDGV();
            panel4.Enabled = true;
        }

        private void cbUseMaterialPlanning_CheckedChanged(object sender, EventArgs e)
        {
            panel4.Enabled = false;
            ShowData();
            DrawDGV();
            panel4.Enabled = true;
        }

        private void cbUsingMaterial_CheckedChanged(object sender, EventArgs e)
        {
            panel4.Enabled = false;
            ShowData();
            DrawDGV();
            panel4.Enabled = true;
        }

        private void cbAddDay_CheckedChanged(object sender, EventArgs e)
        {
            panel4.Enabled = false;
            ShowData();
            DrawDGV();
            panel4.Enabled = true;
        }

        private void cbDontShowAfter_CheckedChanged(object sender, EventArgs e)
        {
            panel4.Enabled = false;
            ShowData();
            DrawDGV();
            panel4.Enabled = true;
        }

        private void cbViews_SelectedIndexChanged(object sender, EventArgs e)
        {
            panel4.Enabled = false;
            ShowData();
            DrawDGV();
            panel4.Enabled = true;
        }

        private void dataGridViewMain_Sorted(object sender, EventArgs e)
        {
            DrawDGV();
        }

        private void dataGridViewMain_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            //DrawDGV();
        }
    }
}
